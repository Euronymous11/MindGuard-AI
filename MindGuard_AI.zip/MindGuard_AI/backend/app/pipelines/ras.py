from typing import Any, Dict

# Risk keyword groups
_HIGH_RISK_KEYWORDS = [
    "suicidal",
    "kill myself",
    "worthless",
    "hopeless",
    "can't go on",
    "end my life",
    "no reason to live",
    "give up",
    "cutting",
    "self-harm",
]
_MEDIUM_RISK_KEYWORDS = [
    "numb",
    "empty",
    "lonely",
    "anxious",
    "panic",
    "i hate myself",
    "everyone hates me",
    "overwhelmed",
    "can't breathe",
]

# Component weights
_WEIGHTS = {
    "sentiment": {"positive": 0, "neutral": 1, "negative": 2},
    "emotion": {
        "joy": 0,
        "neutral": 1,
        "sadness": 2,
        "fear": 2,
        "anger": 2,
        "disgust": 3,
        "surprise": 1,
    },
    "mood_score": lambda mood: 3 if mood <= 2 else (2 if mood <= 4 else 1),
    "keyword": {"low": 0, "medium": 2, "high": 4},
}


def _keyword_level(text: str) -> str:
    text = text.lower()
    if any(kw in text for kw in _HIGH_RISK_KEYWORDS):
        return "high"
    if any(kw in text for kw in _MEDIUM_RISK_KEYWORDS):
        return "medium"
    return "low"


def calculate_mood_score(sentiment_label: str, emotion_label: str) -> int:
    sentiment_val = _WEIGHTS["sentiment"].get(sentiment_label.lower(), 1)
    emotion_val = _WEIGHTS["emotion"].get(emotion_label.lower(), 1)
    return round((sentiment_val + emotion_val) / 2)


def calculate_risk(
    sentiment_label: str, emotion_label: str, mood_score: Any, text: str
) -> int:
    try:
        sentiment_val = _WEIGHTS["sentiment"].get(sentiment_label.lower(), 1)
        emotion_val = _WEIGHTS["emotion"].get(emotion_label.lower(), 1)
        mood_val = _WEIGHTS["mood_score"](int(float(mood_score)))
        keyword_val = _WEIGHTS["keyword"][_keyword_level(text)]

        total = sentiment_val + emotion_val + mood_val + keyword_val
        return min(total, 10)
    except Exception as e:
        from app.core.logger import logger

        logger.exception("Risk score calculation failed")
        return 5
