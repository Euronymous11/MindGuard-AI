# backend/app/core/logger.py

import os
os.makedirs("logs", exist_ok=True)

import logging
import sys
from logging.handlers import RotatingFileHandler

from app.core.config import get_settings

settings = get_settings()

# Create logger
logger = logging.getLogger("mindguard_logger")
logger.setLevel(logging.DEBUG if settings.DEBUG else logging.INFO)

# Formatter
formatter = logging.Formatter(
    "[%(asctime)s] [%(levelname)s] - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

# Console Handler
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

# File Handler (optional, logs to file as well)
file_handler = RotatingFileHandler(
    "logs/mindguard.log", maxBytes=5_000_000, backupCount=3, encoding="utf-8"
)
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

logger.debug("Logger initialized. DEBUG mode is %s", settings.DEBUG)
