// src/components/dashboard/AmbientOverlay.jsx

import React, { useEffect, useState } from "react";
import { X } from "lucide-react";

// Dummy mode for testing
const dummyTopEmotion = "sad";

const audioMap = {
  sad: "/sounds/rain.mp3",
  calm: "/sounds/waves.mp3",
  angry: "/sounds/fire.mp3",
};

const overlayMap = {
  sad: "bg-[url('/overlays/rain.gif')]",
  calm: "bg-[url('/overlays/mist.gif')]",
  angry: "bg-[url('/overlays/fire.gif')]",
};

const AmbientOverlay = () => {
  const [visible, setVisible] = useState(true);
  const audioFile = audioMap[dummyTopEmotion];
  const overlayClass = overlayMap[dummyTopEmotion];

  useEffect(() => {
    const audio = new Audio(audioFile);
    audio.loop = true;
    audio.volume = 0.3;

    if (visible) {
      // ✅ Prevent autoplay error
      audio.play().catch((err) => {
        console.warn("Autoplay blocked until user interacts", err);
      });
    }

    return () => {
      audio.pause();
    };
  }, [audioFile, visible]);

  if (!visible || !dummyTopEmotion) return null;

  return (
    <div
      className={`fixed inset-0 z-10 ${overlayClass} bg-cover bg-center opacity-20 pointer-events-none`}
    >
      <button
        onClick={() => setVisible(false)}
        className="absolute top-4 right-4 z-20 bg-white text-gray-800 px-2 py-1 rounded shadow text-xs"
      >
        <X size={14} className="inline" /> Dismiss Ambience
      </button>
    </div>
  );
};

export default AmbientOverlay;
