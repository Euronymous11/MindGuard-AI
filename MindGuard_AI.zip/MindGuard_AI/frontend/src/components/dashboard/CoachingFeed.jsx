import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import axios from "axios";
import { Volume2 } from "lucide-react";

const CoachingFeed = () => {
  const [feed, setFeed] = useState([]);

  useEffect(() => {
    const dummyFeed = [
      {
        user_message: "I can't handle the pressure of exams.",
        reframe: "You're facing a tough time, but it shows you're committed. That’s strength, not failure.",
        tip: "Break down your study into 25-minute focus sessions with 5-minute breaks (Pomodoro technique).",
        timestamp: "2025-05-10T10:30:00",
      },
      {
        user_message: "I don’t feel motivated to do anything.",
        reframe: "It's okay to feel this way. Starting small builds momentum.",
        tip: "Try a 5-minute starter task—just begin, even if it's tiny.",
        timestamp: "2025-05-09T18:15:00",
      },
      {
        user_message: "I’m worried I’ll disappoint my family.",
        reframe: "Your effort matters more than outcome. You're already showing care by trying.",
        tip: "List 3 recent things you’ve done that you're proud of—even small wins count.",
        timestamp: "2025-05-08T16:00:00",
      },
    ];

    setFeed(dummyFeed);
  }, []);

  if (feed.length === 0) {
    return <p className="text-gray-500 text-sm">No coaching tips available yet.</p>;
  }

  const speakTip = (text) => {
    const speech = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(speech);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white rounded-xl p-5 shadow-md"
    >
      <h2 className="text-lg font-bold mb-4">💡 AI Coaching Feed</h2>

      <div className="space-y-4">
        {feed.map((item, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 * idx }}
            className="p-4 border rounded-lg shadow-sm bg-blue-50 relative group"
            title={`Generated: ${new Date(item.timestamp).toLocaleString()}`}
          >
            <p className="text-sm text-gray-700">
              <strong>🧍‍♂️ You:</strong> {item.user_message}
            </p>

            {item.reframe && (
              <p className="text-green-700 mt-2">
                <strong>🔁 Reframe:</strong>{" "}
                <span className="italic">{item.reframe}</span>
              </p>
            )}

            {item.tip && (
              <div className="flex items-start gap-2 mt-2">
                <p className="text-indigo-600 text-sm">
                  <strong>💡 Tip:</strong>{" "}
                  <span className="font-medium">{item.tip}</span>
                </p>
                <button
                  onClick={() => speakTip(item.tip)}
                  className="text-blue-500 hover:text-blue-700 transition"
                  title="Hear Tip"
                >
                  <Volume2 size={16} />
                </button>
              </div>
            )}

            <p className="text-xs text-gray-400 mt-1">
              {new Date(item.timestamp).toLocaleString()}
            </p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default CoachingFeed;
