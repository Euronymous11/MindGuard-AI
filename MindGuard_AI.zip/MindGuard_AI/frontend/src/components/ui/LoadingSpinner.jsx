import React from "react";

const LoadingSpinner = () => {
  return (
    <div className="flex items-center gap-2 mt-2 animate-pulse text-sm text-gray-500">
      <div className="h-2 w-2 bg-gray-400 rounded-full animate-bounce"></div>
      <div className="h-2 w-2 bg-gray-400 rounded-full animate-bounce delay-100"></div>
      <div className="h-2 w-2 bg-gray-400 rounded-full animate-bounce delay-200"></div>
      <span className="ml-2 italic">MindGuard AI is typing...</span>
    </div>
  );
};

export default LoadingSpinner;
