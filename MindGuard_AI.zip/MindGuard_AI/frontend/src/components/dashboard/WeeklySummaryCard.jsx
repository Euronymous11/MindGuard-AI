import React, { useEffect, useState } from "react";
import { Sparkles, Volume2 } from "lucide-react";
import { motion } from "framer-motion";

const WeeklySummaryCard = () => {
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    // Dummy summary for test user mode
    const dummy = {
      summary:
        "You maintained emotional stability this week with calm, happy moods. Today you showed excellent focus and positivity.",
      avg_mood: 4.5,
      avg_risk: 2,
      top_emotions: ["calm", "happy"],
      created_at: "2025-05-12T12:00:00", // ✅ Today
    };


    setSummary(dummy);

    // 🔊 Auto TTS on load
    const speech = new SpeechSynthesisUtterance(dummy.summary);
    window.speechSynthesis.speak(speech);
  }, []);

  if (!summary) return null;

  const highlight =
    summary.avg_mood >= 4 ? "animate-pulse text-blue-800" : "text-gray-800";
  const topEmotion = summary.top_emotions?.[0];

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white rounded-xl p-6 shadow-md border-l-4 border-blue-500 relative"
    >
      {/* 🎯 Floating Overlay */}
      {summary.avg_mood && topEmotion && (
        <div className="absolute top-3 right-4 text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full shadow-md animate-fade-in">
          😊 Avg Mood: {summary.avg_mood} · 🎯 {topEmotion}
        </div>
      )}

      <div className="flex items-center gap-3 mb-2">
        <Sparkles className="text-blue-500" />
        <h3 className="text-lg font-bold">🧠 Weekly Emotional Summary</h3>
      </div>

      <p className={`mb-3 leading-relaxed whitespace-pre-wrap ${highlight}`}>
        {summary.summary}
      </p>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm text-gray-600 mt-4">
        <div>
          <span className="font-semibold">📆 Date:</span>{" "}
          {summary.created_at
            ? new Date(summary.created_at).toLocaleDateString()
            : "N/A"}
        </div>
        <div>
          <span className="font-semibold">😊 Avg Mood:</span>{" "}
          {summary.avg_mood ?? "N/A"}/5
        </div>
        <div>
          <span className="font-semibold">⚠ Avg Risk:</span>{" "}
          {summary.avg_risk ?? "N/A"}/10
        </div>
        <div className="col-span-2 md:col-span-1">
          <span className="font-semibold">🎯 Top Emotions:</span>{" "}
          {summary.top_emotions?.join(", ") || "None"}
        </div>
      </div>

      {/* 🔊 Replay Button */}
      <button
        onClick={() =>
          window.speechSynthesis.speak(
            new SpeechSynthesisUtterance(summary.summary)
          )
        }
        className="mt-4 inline-flex items-center gap-2 text-sm text-blue-600 hover:underline"
      >
        <Volume2 size={16} />
        Replay Summary
      </button>
    </motion.div>
  );
};

export default WeeklySummaryCard;
