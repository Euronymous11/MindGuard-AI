# backend/app/core/config.py

import os
from functools import lru_cache
from dotenv import load_dotenv
load_dotenv()

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Project
    PROJECT_NAME: str = "MindGuard AI"
    API_V1_STR: str = "/api/v1"

    # Debug mode
    DEBUG: bool = os.getenv("DEBUG", "True").lower() == "true"

    # Postgres
    POSTGRES_USER: str = os.getenv("POSTGRES_USER", "postgres")
    POSTGRES_DB: str = os.getenv("POSTGRES_DB", "mindguard_db")
    POSTGRES_HOST: str = os.getenv("POSTGRES_HOST", "localhost")
    POSTGRES_PORT: int = int(os.getenv("POSTGRES_PORT", "5432"))

    DATABASE_URL: str = f"{POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DB}"

    # Secrets & API keys
    OPENAI_API_KEY: str
    HUGGINGFACE_API_KEY: str = ""
    JWT_SECRET_KEY: str = os.getenv("JWT_SECRET_KEY", "")
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 1 week

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
