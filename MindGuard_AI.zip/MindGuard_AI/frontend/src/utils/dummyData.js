// utils/dummyData.js
export const dummyDashboardData = {
  moodCalendar: [
    { date: "2025-05-01", mood: 4 },
    { date: "2025-05-02", mood: 2 },
    { date: "2025-05-03", mood: 5 },
    { date: "2025-05-04", mood: 3 },
  ],
  emotionFrequency: {
    happy: 12,
    sad: 4,
    angry: 1,
    calm: 6,
    surprised: 3,
  },
  weeklySummary: {
    avgMood: 3.6,
    topEmotions: ["happy", "calm"],
    summary:
      "This week showed overall positive mood trends with slight emotional spikes mid-week.",
  },
  badges: [
    { id: 1, title: "Mood Streak: 3 Days", type: "streak" },
    { id: 2, title: "First Journal Entry", type: "milestone" },
  ],
  journalEntries: [
    {
      id: "j1",
      content: "I felt much better after talking to the chatbot today.",
      date: "2025-05-03",
    },
    {
      id: "j2",
      content: "Had a rough morning but calmed down by afternoon.",
      date: "2025-05-04",
    },
  ],
};
