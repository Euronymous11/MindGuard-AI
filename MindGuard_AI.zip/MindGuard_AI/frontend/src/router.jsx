// src/router.jsx
import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

/* ── Public pages ─────────────────────────────────────────── */
import Landing     from "@/pages/Landing";
import LoginSignup from "@/pages/LoginSignup";

/* ── Private pages ────────────────────────────────────────── */
import Chat        from "@/pages/Chat";
import Dashboard   from "@/pages/Dashboard";
import Profile     from "@/pages/Profile";

/* ── Shared UI ────────────────────────────────────────────── */
import Navbar      from "@/components/Navbar";

/* ───────────────── Auth guard ────────────────────────────── */
const PrivateRoute = ({ children }) => {
  const token = localStorage.getItem("auth_token");
  return token ? children : <Navigate to="/auth" replace />;
};

/* ───────────── Layout that adds the navbar ───────────────── */
const PrivateLayout = ({ children }) => (
  <>
    <Navbar />
    {/* push content below the fixed navbar */}
    <main className="pt-16 px-4 md:px-8">{children}</main>
  </>
);

/* ─────────────────── Router config ───────────────────────── */
const AppRouter = () => (
  // NOTE: <BrowserRouter> lives in main.jsx
  <Routes>
    {/* ── Public (no navbar) ─ */}
    <Route path="/"      element={<Landing />} />
    <Route path="/auth"  element={<LoginSignup />} />

    {/* ── Private (with navbar) ─ */}
    <Route
      path="/dashboard"
      element={
        <PrivateRoute>
          <PrivateLayout>
            <Dashboard />
          </PrivateLayout>
        </PrivateRoute>
      }
    />
    <Route
      path="/chat"
      element={
        <PrivateRoute>
          <PrivateLayout>
            <Chat />
          </PrivateLayout>
        </PrivateRoute>
      }
    />
    <Route
      path="/profile"
      element={
        <PrivateRoute>
          <PrivateLayout>
            <Profile />
          </PrivateLayout>
        </PrivateRoute>
      }
    />

    {/* ── Fallback ─ */}
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>
);

export default AppRouter;
