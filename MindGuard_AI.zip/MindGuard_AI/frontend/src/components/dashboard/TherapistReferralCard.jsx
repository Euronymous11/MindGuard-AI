import React from "react";
import { motion } from "framer-motion";
import { AlertTriangle } from "lucide-react";

const TherapistReferralCard = ({ riskScore = 9 }) => {
  if (riskScore < 7) return null;

  const severity = riskScore >= 10 ? "High" : "Moderate";
  const colorClass = riskScore >= 10
    ? "bg-red-100 border-red-500 animate-pulse"
    : "bg-yellow-100 border-yellow-400";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className={`border-l-4 ${colorClass} p-5 rounded-md shadow-md mt-4`}
    >
      <h3 className="text-lg font-bold flex items-center gap-2 text-red-800">
        <AlertTriangle className="text-red-500" size={20} />
        Therapist Referral Recommended
      </h3>

      <p className="text-sm text-gray-700 mt-2">
        Your Risk Assessment Score is{" "}
        <span className="font-bold">{riskScore}</span> ({severity} Risk).
        We strongly suggest you consider speaking with a licensed therapist.
      </p>

      <div className="mt-4">
        <a
          href="https://www.psychologytoday.com"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded hover:scale-105 transition transform shadow"
        >
          🧠 Find a Therapist
        </a>
      </div>
    </motion.div>
  );
};

export default TherapistReferralCard;
