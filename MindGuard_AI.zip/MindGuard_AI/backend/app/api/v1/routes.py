from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.services import (
    process_message,
    submit_mood,
    get_all_moods,
    get_weekly_mood_trend,
    create_weekly_summary,
    get_latest_summary,
    evaluate_phq9,
    evaluate_gad7,
    evaluate_badges,
    provide_coaching_tip,
)

from app.schemas import (
    ChatRequest,
    ChatResponse,
    MoodCreate,
    Mood,
    WeeklyTrend,
    WeeklySummary,
    PHQ9Request,
    GAD7Request,
    BadgeRequest,
    CoachingTip,
)

from app.db.session import get_db

router = APIRouter(prefix="/api/v1")

# -------------------- CHAT --------------------
@router.post("/chat/message", response_model=ChatResponse, tags=["Chat"])
def chat_message(request: ChatRequest, db: Session = Depends(get_db)):
    return process_message(db=db, request=request)

# -------------------- MOOD --------------------
@router.post("/mood/submit", response_model=Mood, tags=["Mood"])
def submit_user_mood(mood: MoodCreate, db: Session = Depends(get_db)):
    return submit_mood(db=db, user_id="demo", mood_data=mood)  # assuming single-user

@router.get("/mood/all", response_model=list[Mood], tags=["Mood"])
def list_all_moods(db: Session = Depends(get_db)):
    return get_all_moods(db=db, user_id="demo")

@router.get("/mood/weekly-trend", response_model=WeeklyTrend, tags=["Mood"])
def get_weekly_trend(db: Session = Depends(get_db)):
    return get_weekly_mood_trend(db=db, user_id="demo")

# -------------------- SUMMARY --------------------
@router.post("/summary/generate", response_model=WeeklySummary, tags=["Summary"])
def generate_summary_route(db: Session = Depends(get_db)):
    return create_weekly_summary(db=db, user_id="demo")

@router.get("/summary/latest", response_model=WeeklySummary, tags=["Summary"])
def get_latest_summary_route(db: Session = Depends(get_db)):
    return get_latest_summary(db=db, user_id="demo")

# -------------------- TESTS --------------------
@router.post("/test/phq9", response_model=dict, tags=["Test"])
def submit_phq9(request: PHQ9Request):
    return evaluate_phq9(request.scores)

@router.post("/test/gad7", response_model=dict, tags=["Test"])
def submit_gad7(request: GAD7Request):
    return evaluate_gad7(request.scores)

# -------------------- BADGES --------------------
@router.post("/badge/award", response_model=dict, tags=["Badge"])
def award_badge(request: BadgeRequest, db: Session = Depends(get_db)):
    return {"awarded": evaluate_badges(db=db, user_id="demo")}

# -------------------- COACHING --------------------
@router.get("/coach/tip", response_model=CoachingTip, tags=["Coaching"])
def get_tip():
    return {
        "tip": provide_coaching_tip("neutral", "calm"),
        "focus_area": "emotional wellbeing"
    }
api_router = router
