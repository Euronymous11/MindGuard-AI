// src/components/chat/CrisisLockdown.jsx

import React from "react";
import { AlertTriangle } from "lucide-react";
import { motion } from "framer-motion";

const CrisisLockdown = () => {
  return (
    <motion.div
      className="fixed inset-0 z-50 bg-black bg-opacity-80 flex items-center justify-center p-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
    >
      <motion.div
        className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6 text-center border-2 border-red-500"
        initial={{ scale: 0.8 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 20 }}
      >
        <div className="flex flex-col items-center space-y-4">
          <AlertTriangle className="text-red-600 w-10 h-10" />
          <h2 className="text-xl font-semibold text-red-700">
            Immediate Attention Needed
          </h2>
          <p className="text-gray-700">
            We've detected signs of emotional crisis in this session.
            <br />
            You're not alone — we’re here to help.
          </p>
          <div className="mt-4 space-y-2">
            <a
              href="tel:9152987821"
              className="block bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-md transition"
            >
              📞 Call Mental Health Helpline
            </a>
            <a
              href="https://www.nimhans.ac.in/helpline/"
              target="_blank"
              rel="noopener noreferrer"
              className="block text-sm text-blue-600 hover:underline"
            >
              Or visit NIMHANS Crisis Services →
            </a>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default CrisisLockdown;
