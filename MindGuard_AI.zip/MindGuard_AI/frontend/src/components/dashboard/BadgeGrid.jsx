import React from "react";
import { motion } from "framer-motion";
import {
  TooltipProvider,
  Tooltip,
  TooltipTrigger,
  TooltipContent,
  TooltipArrow,
} from "@radix-ui/react-tooltip";
import { BadgeCheck, Star, Award } from "lucide-react";

const badges = [
  {
    id: 1,
    title: "Streak Master",
    description: "7-day mood streak achieved!",
    icon: <BadgeCheck className="w-10 h-10 text-green-600" />,
    date: "2025-05-09",
    rarity: "Common",
  },
  {
    id: 2,
    title: "First Journal Entry",
    description: "Started your self-reflection journey.",
    icon: <Star className="w-10 h-10 text-yellow-500" />,
    date: "2025-05-08",
    rarity: "Rare",
  },
  {
    id: 3,
    title: "Emotional Explorer",
    description: "Identified 5 emotions in chat.",
    icon: <Award className="w-10 h-10 text-purple-600" />,
    date: "2025-05-07",
    rarity: "Epic",
  },
];

const rarityStyles = {
  Common: "bg-green-50 text-green-700 ring-green-300",
  Rare: "bg-yellow-50 text-yellow-700 ring-yellow-300",
  Epic: "bg-purple-50 text-purple-700 ring-purple-300",
};

const BadgeGrid = () => {
  return (
    <TooltipProvider>
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
        {badges.map((badge) => (
          <Tooltip key={badge.id} delayDuration={100}>
            <TooltipTrigger asChild>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`rounded-xl p-5 text-center border border-gray-200 shadow-md hover:shadow-lg transition-all ring-1 ${rarityStyles[badge.rarity]} cursor-pointer`}
              >
                <div className="flex flex-col items-center space-y-3">
                  <div className="p-3 rounded-full bg-white shadow-inner">
                    {badge.icon}
                  </div>
                  <h4 className="font-semibold text-md">{badge.title}</h4>
                  <span className="text-xs font-medium px-3 py-1 rounded-full bg-white shadow-sm">
                    {badge.rarity}
                  </span>
                  <p className="text-sm text-gray-600 leading-snug">{badge.description}</p>
                  <p className="text-xs text-gray-400 mt-1">
                    🗓️ Earned on {badge.date}
                  </p>
                </div>
              </motion.div>
            </TooltipTrigger>
            <TooltipContent
              className="bg-black text-white text-xs px-3 py-1.5 rounded shadow-lg max-w-[200px]"
              side="top"
              sideOffset={6}
            >
              {badge.description}
              <TooltipArrow className="fill-black" />
            </TooltipContent>
          </Tooltip>
        ))}
      </div>
    </TooltipProvider>
  );
};

export default BadgeGrid;
