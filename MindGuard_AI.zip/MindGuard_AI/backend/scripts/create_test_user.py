#!/usr/bin/env python
import os
import sys

# Make sure `app/` is on PYTHONPATH
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sqlalchemy.orm import Session

from app.db.session import SessionLocal
from app.models.user import User
from app.services.auth_service import hash_password


def main():
    db: Session = SessionLocal()
    try:
        test_email = "test@mindguard.ai"
        test_password = "password123"

        # If email already exists, skip creation.
        if db.query(User).filter_by(email=test_email).first():
            print(f"⚠️  Test user already exists with email {test_email}, skipping.")
            return

        # Find a free username base
        base_username = "testuser"
        username = base_username
        suffix = 1
        while db.query(User).filter_by(username=username).first():
            username = f"{base_username}{suffix}"
            suffix += 1

        new_user = User(
            username=username,
            email=test_email,
            password=hash_password(test_password),
            emergency_name="Emergency Contact",
            emergency_email="emergency@mindguard.ai",
            emergency_phone="000-000-0000",
        )
        db.add(new_user)
        db.commit()

        print(f"✅ Created test user:")
        print(f"   • username: {username}")
        print(f"   • email:    {test_email}")
        print(f"   • password: {test_password}")
    finally:
        db.close()


if __name__ == "__main__":
    main()
