import React from "react";

const TestLauncher = ({ onStart }) => {
  return (
    <div className="p-6 rounded-lg border shadow-md max-w-xl mx-auto text-center">
      <h2 className="text-xl font-bold mb-4">🧠 Start a Mental Health Assessment</h2>
      <p className="text-gray-600 mb-6">Choose a test below to evaluate your emotional well-being.</p>
      <div className="flex justify-center gap-4">
        <button onClick={() => onStart("PHQ-9")} className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
          PHQ-9 (Depression)
        </button>
        <button onClick={() => onStart("GAD-7")} className="bg-purple-500 text-white px-4 py-2 rounded hover:bg-purple-600">
          GAD-7 (Anxiety)
        </button>
      </div>
    </div>
  );
};

export default TestLauncher;
