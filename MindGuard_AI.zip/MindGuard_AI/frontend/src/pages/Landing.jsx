import React from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

const Landing = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-50 to-white">
      {/* Top Navigation */}
      <header className="w-full flex items-center justify-between px-6 py-4 bg-white shadow-md">
        <h1 className="text-2xl font-extrabold text-blue-600 tracking-wide">MindGuard AI</h1>
        <div className="space-x-4">
          <button
            onClick={() => navigate("/auth")}
            className="text-blue-600 font-medium hover:underline"
          >
            Login
          </button>
          <button
            onClick={() => navigate("/auth")}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            Sign Up
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <motion.section
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="flex-grow flex flex-col items-center justify-center text-center px-6 py-16"
      >
        <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4 leading-snug">
          Emotional Wellness. Powered by Intelligence.
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mb-6">
          MindGuard AI is your personal mental health ally — offering AI-driven support, mood tracking,
          CBT coaching, and emergency detection when you need it most.
        </p>
        <div className="space-x-4">
          <button
            onClick={() => navigate("/auth")}
            className="bg-blue-600 text-white px-6 py-3 rounded-xl text-lg hover:bg-blue-700 shadow-md"
          >
            Get Started
          </button>
          <a
            href="#features"
            className="text-blue-600 underline text-lg font-medium"
          >
            Learn More
          </a>
        </div>
      </motion.section>

      {/* Features Section */}
      <section
        id="features"
        className="bg-white py-16 px-6 md:px-20 text-center"
      >
        <h3 className="text-2xl font-bold mb-10 text-blue-600">
          Why MindGuard AI?
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10 text-gray-700 text-left">
          <div>
            <h4 className="text-xl font-semibold mb-2">🧠 AI-Powered Chat</h4>
            <p>Talk to an intelligent, caring assistant trained in CBT and real-time emotional response.</p>
          </div>
          <div>
            <h4 className="text-xl font-semibold mb-2">📊 Mood & Risk Tracking</h4>
            <p>Track daily mood trends, risk spikes, and emotional shifts over time — automatically.</p>
          </div>
          <div>
            <h4 className="text-xl font-semibold mb-2">🏆 Gamification & Coaching</h4>
            <p>Unlock achievements, receive tailored guidance, and grow with personalized tips and badges.</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-center py-6 text-sm text-gray-500 bg-gray-100">
        © {new Date().getFullYear()} MindGuard AI · All rights reserved.
      </footer>
    </div>
  );
};

export default Landing;
