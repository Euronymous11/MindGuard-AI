import os
import logging
from openai import OpenAI, OpenAIError
from openai.types.chat import ChatCompletion
from dotenv import load_dotenv
from typing import Optional

load_dotenv()

# Logger setup
logger = logging.getLogger("AIEngine")
logger.setLevel(logging.INFO)

# OpenAI client with API key
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Load default model from environment or fallback
DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo")

def get_ai_response(message: str, model: Optional[str] = None) -> str:
    """
    Generate AI response for a given user message using OpenAI chat completion API.

    Args:
        message (str): User's input message.
        model (str, optional): Override model name (default: from .env or gpt-3.5-turbo).

    Returns:
        str: AI-generated response or fallback string on failure.
    """
    try:
        response: ChatCompletion = client.chat.completions.create(
            model=model or DEFAULT_MODEL,
            messages=[
                {"role": "system", "content": "You are a calm, empathetic mental health assistant that replies with emotional intelligence and clarity."},
                {"role": "user", "content": message}
            ],
            temperature=0.6,
            max_tokens=200,
            timeout=10  # seconds
        )

        reply = response.choices[0].message.content.strip()
        logger.info(f"[AI Response] {reply}")
        return reply

    except OpenAIError as e:
        logger.error(f"[AI ERROR] {e}")
        return "I'm experiencing some issues responding right now. Please try again in a moment."
