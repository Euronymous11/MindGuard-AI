# backend/app/utils/analyzer.py

from app.core.logger import logger
from app.pipelines.emotion import analyze_emotion
from app.pipelines.ras import calculate_mood_score, calculate_risk
from app.pipelines.sentiment import analyze_sentiment


def analyze_text(text: str) -> dict:
    try:
        sentiment = analyze_sentiment(text)
        emotion = analyze_emotion(text)

        sentiment_label = sentiment.get("label", "neutral")
        emotion_label = emotion.get("label", "neutral")

        # Ensure mood_score is float for further processing
        mood_score = calculate_mood_score(sentiment_label, emotion_label)
        risk_score = calculate_risk(sentiment_label, emotion_label, mood_score, text)

        return {
            "sentiment": sentiment_label,
            "emotion": {
                "emotion": emotion_label,
                "confidence": emotion.get("confidence", 0.0),
            },
            "mood_score": float(mood_score),
            "risk_score": float(risk_score),
        }

    except Exception as e:
        logger.exception("Analysis pipeline failed")
        return {
            "sentiment": "neutral",
            "emotion": {"emotion": "neutral", "confidence": 0.0},
            "mood_score": 3.0,
            "risk_score": 1.0,
        }
