# backend/app/utils/coaching.py

import logging
from openai import OpenAI
from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

client = OpenAI(api_key=settings.OPENAI_API_KEY)


def generate_reframe(distortion: str, message: str) -> str:
    """
    Generate a CBT reframe for a given distorted thought using OpenAI's v1 SDK.
    """
    prompt = f"""You are a CBT therapist. The user has shown cognitive distortion: "{distortion}".
Help reframe their negative thought into a positive, realistic one.

Original thought: "{message}"

Respond with just the reframed statement, nothing else.
"""

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=60,
        )
        return response.choices[0].message.content.strip()

    except Exception as e:
        logger.error("OpenAI reframe generation failed", exc_info=True)
        return "Let's try to see this situation differently."


def get_coaching_tip(emotion: str) -> str:
    """
    Return a coaching tip based on the user's emotion.
    """
    tips = {
        "sadness": "Try a 5-minute journaling session or a nature walk.",
        "anger": "Take a deep breath. Try a grounding exercise.",
        "fear": "Practice box breathing or call a friend for reassurance.",
        "joy": "Celebrate this! Capture the moment in your journal.",
        "disgust": "Clean or reorganize something small. Regain control.",
        "surprise": "Reflect — what can you learn from this surprise?",
        "neutral": "Maintain balance with hydration and a short break.",
    }
    return tips.get(emotion.lower(), "Take a mindful pause and check in with yourself.")
