// src/pages/Dashboard.jsx

import React from "react";
import { motion } from "framer-motion";

// Core Enhancements
import AmbientOverlay from "@/components/dashboard/AmbientOverlay";
import EmotionThemeWrapper from "@/components/wrappers/EmotionThemeWrapper";

// Top Banner & Emotion
import WellnessCarousel from "@/components/dashboard/WellnessCarousel";
import MoodCalendar from "@/components/dashboard/MoodCalendar";
import EmotionRadarChart from "@/components/dashboard/EmotionRadarChart";
import MoodTrendGraph from "@/components/dashboard/MoodTrendGraph";
import MoodStreaks from "@/components/dashboard/MoodStreaks";
import RiskTimeline from "@/components/dashboard/RiskTimeline";
import WeeklySummaryCard from "@/components/dashboard/WeeklySummaryCard";

// Reflection & Coaching
import JournalViewer from "@/components/dashboard/JournalViewer";
import CoachingFeed from "@/components/dashboard/CoachingFeed";
import CognitiveInsightRibbon from "@/components/dashboard/CognitiveInsightRibbon";
import EmotionWordCloud from "@/components/dashboard/EmotionWordCloud";

// Gamification
import BadgeGrid from "@/components/dashboard/BadgeGrid";
import MoodPackUnlockCard from "@/components/dashboard/MoodPackUnlockCard";
import MoodTimeline from "@/components/dashboard/MoodTimeline";

// Export & Escalation
import WeeklyReportDownloader from "@/components/dashboard/WeeklyReportDownloader";
import TherapistReferralCard from "@/components/dashboard/TherapistReferralCard";

const Dashboard = () => {
  const dummyJournals = [
    {
      entry: "Felt anxious about deadlines, but managed with planning.",
      timestamp: "2025-05-10T09:00:00",
    },
    {
      entry: "Had a good conversation with a friend. Felt heard.",
      timestamp: "2025-05-09T14:00:00",
    },
  ];

  const showReferral = true;
  const topEmotion = "Calm";

  return (
    <>
      <AmbientOverlay />
      <EmotionThemeWrapper>
        <div className="max-w-screen-xl mx-auto px-4">

          {/* 🌤️ Sticky Header */}
          <div className="sticky top-0 z-30 bg-white/80 backdrop-blur-md px-4 py-3 mb-4 rounded-b shadow">
            <h2 className="text-xl font-bold text-blue-700 flex justify-between items-center">
              Welcome to your Dashboard
              <span className="text-sm text-gray-500 font-medium">
                Emotion: 😊 {topEmotion}
              </span>
            </h2>
          </div>

          {/* 🌱 Weekly Emotion Summary */}
          <div className="bg-teal-100 border border-teal-300 text-teal-800 p-4 rounded-lg shadow mb-4">
            🌿 You've been feeling <strong>{topEmotion.toLowerCase()}</strong> this week. Keep up the balanced energy!
          </div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            {/* 🌀 Insight Carousel */}
            <div className="col-span-full mb-6">
              <WellnessCarousel />
            </div>

            {/* 📌 Deep Mood & Cognitive Insights (Long Format) */}
            <h3 className="text-lg font-semibold text-gray-700 mb-2">📌 Deep Mood & Cognitive Insights</h3>
            <div className="grid grid-cols-1 gap-6 mb-6">
              <MoodTimeline />
              <MoodTrendGraph />
              <MoodCalendar />
              <CognitiveInsightRibbon />
            </div>

            {/* 🩺 Weekly Wellness Highlights */}
            <h3 className="text-lg font-semibold text-gray-700 mb-2">🩺 Weekly Wellness Highlights</h3>
            <div className="grid grid-cols-1 gap-6 mb-6">
              <WeeklySummaryCard />
            </div>

            {/* 🧠 Self-Reflection & Coaching */}
            <h3 className="text-lg font-semibold text-gray-700 mb-2">🧠 Self-Reflection & Coaching</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-6">
              <JournalViewer journals={dummyJournals} />
              <CoachingFeed />
              <EmotionWordCloud />
            </div>

            {/* 🏆 Earned Badges & Unlocks */}
            <h3 className="text-lg font-semibold text-gray-700 mb-2">🏆 Earned Badges & Unlockables</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-6">
              <BadgeGrid />
              <MoodPackUnlockCard />
            </div>

            {/* 📥 Weekly Report & Support */}
            <h3 className="text-lg font-semibold text-gray-700 mb-2">📥 Weekly Report & Support</h3>
            <div className="col-span-full mb-6">
              <WeeklyReportDownloader />
            </div>

            {showReferral && (
              <div className="mt-6">
                <TherapistReferralCard />
              </div>
            )}
          </motion.div>
        </div>
      </EmotionThemeWrapper>
    </>
  );
};

export default Dashboard;
