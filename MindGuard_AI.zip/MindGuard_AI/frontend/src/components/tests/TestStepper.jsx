import React, { useState } from "react";
import testService from "@/services/testService";
import TestResultCard from "./TestResultCard";

const QUESTIONS = {
  "PHQ-9": [
    "Little interest or pleasure in doing things",
    "Feeling down, depressed, or hopeless",
    "Trouble falling or staying asleep, or sleeping too much",
    "Feeling tired or having little energy",
    "Poor appetite or overeating",
    "Feeling bad about yourself — or that you are a failure",
    "Trouble concentrating on things",
    "Moving or speaking slowly or being fidgety",
    "Thoughts that you would be better off dead"
  ],
  "GAD-7": [
    "Feeling nervous, anxious, or on edge",
    "Not being able to stop or control worrying",
    "Worrying too much about different things",
    "Trouble relaxing",
    "Being so restless that it is hard to sit still",
    "Becoming easily annoyed or irritable",
    "Feeling afraid as if something awful might happen"
  ]
};

const OPTIONS = ["Not at all", "Several days", "More than half the days", "Nearly every day"];

const TestStepper = ({ testType, onDone }) => {
  const questions = QUESTIONS[testType];
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState(Array(questions.length).fill(null));
  const [result, setResult] = useState(null);

  const handleAnswer = (value) => {
    const newAnswers = [...answers];
    newAnswers[step] = value;
    setAnswers(newAnswers);
    if (step + 1 < questions.length) {
      setStep(step + 1);
    } else {
      submitTest(newAnswers);
    }
  };

  const submitTest = async (finalAnswers) => {
    try {
      const res = await testService.submitTest({
        test_type: testType,
        answers: finalAnswers
      });
      setResult(res);
      onDone(res);
    } catch (err) {
      console.error("Test submission failed", err);
    }
  };

  if (result) return <TestResultCard result={result} />;

  return (
    <div className="max-w-xl mx-auto p-6 rounded shadow-lg">
      <h2 className="text-xl font-semibold mb-4">{testType} - Question {step + 1} of {questions.length}</h2>
      <p className="text-gray-800 mb-6">{questions[step]}</p>
      <div className="grid gap-2">
        {OPTIONS.map((label, idx) => (
          <button
            key={idx}
            onClick={() => handleAnswer(idx)}
            className="p-3 rounded bg-gray-100 hover:bg-blue-100 text-left"
          >
            {label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default TestStepper;
