// src/utils/useConfetti.js

import { useCallback } from "react";
import confetti from "canvas-confetti";

const useConfetti = () => {
  return useCallback(() => {
    confetti({
      particleCount: 100,
      spread: 80,
      angle: 90,
      startVelocity: 40,
      origin: { y: 0.6 },
      gravity: 0.9,
      ticks: 200,
      scalar: 1.2,
      zIndex: 9999,
    });
  }, []);
};

export default useConfetti;
