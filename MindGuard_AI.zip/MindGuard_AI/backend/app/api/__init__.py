# app/api/__init__.py

from .v1 import api_router
