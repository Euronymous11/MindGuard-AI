import React from "react";

const TestResultCard = ({ result }) => {
  return (
    <div className="max-w-xl mx-auto p-6 text-center border shadow-lg rounded-lg">
      <h2 className="text-2xl font-bold mb-4">✅ Test Completed</h2>
      <p className="text-lg">Type: <strong>{result.test_type}</strong></p>
      <p className="text-xl mt-2">Score: <strong>{result.score}</strong></p>
      <p className="mt-2 text-green-700 font-semibold">{result.interpretation}</p>
      <p className="text-sm text-gray-400 mt-4">{new Date(result.created_at).toLocaleString()}</p>
    </div>
  );
};

export default TestResultCard;
