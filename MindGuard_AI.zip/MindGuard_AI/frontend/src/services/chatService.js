// src/services/chatService.js

/**
 * Sends a user message to the backend AI chat API.
 * @param {string} message - The user’s text input message.
 * @param {boolean} [isJournal=false] - Whether the message is a journal entry.
 * @returns {Promise<Object>} AI response: { reply, sentiment, emotion, risk, voice_url? }
 */

export const getChatResponse = async (message, isJournal = false) => {
  try {
    const response = await fetch("http://localhost:8000/api/v1/chat/message", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message,
        is_journal: isJournal,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("❌ AI Chat Response Error:", errText);
      throw new Error("Failed to get AI response");
    }

    const data = await response.json();

    return {
      reply: data.reply || "I'm here, but couldn't find a good answer yet.",
      sentiment: data.sentiment || "neutral",
      emotion: data.emotion || { emotion: "neutral", confidence: "low" },
      risk: data.risk ?? null,
      voice_url: data.voice_url ?? null,
    };
  } catch (error) {
    console.error("[ChatServiceError]", error);
    return {
      reply: "⚠️ I'm having trouble responding right now. Try again soon.",
      sentiment: "neutral",
      emotion: { emotion: "neutral", confidence: "fallback" },
      risk: null,
      voice_url: null,
    };
  }
};
