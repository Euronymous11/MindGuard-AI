// src/pages/Chat.jsx

import React, { useEffect, useState, useRef } from "react";
import ChatBox from "@/components/chat/ChatBox";
import MoodPopup from "@/components/chat/MoodPopup";
import CrisisLockdown from "@/components/chat/CrisisLockdown";
import LoadingSpinner from "@/components/ui/LoadingSpinner";
import { getChatResponse } from "@/services/chatService";
import { motion } from "framer-motion";

const Chat = () => {
  const [messages, setMessages] = useState([]);
  const [userInput, setUserInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [showMoodPopup, setShowMoodPopup] = useState(true);
  const [crisisMode, setCrisisMode] = useState(false);
  const chatContainerRef = useRef(null);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTo({
        top: chatContainerRef.current.scrollHeight,
        behavior: "smooth",
      });
    }
  }, [messages, loading]);

  const handleUserSubmit = async (e) => {
    e.preventDefault();
    if (!userInput.trim()) return;

    const newUserMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content: userInput,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, newUserMessage]);
    setLoading(true);
    setUserInput("");

    try {
      const response = await getChatResponse(userInput); // ✅ FIXED payload format
      const { reply, sentiment, emotion, risk, voice_url } = response;

      if (risk === "HIGH") setCrisisMode(true);

      const newBotMessage = {
        id: crypto.randomUUID(),
        role: "ai",
        content: reply,
        sentiment,
        emotion,
        risk,
        voice_url: voice_url || null,
        timestamp: new Date().toISOString(),
      };

      setMessages((prev) => [...prev, newBotMessage]);
      speak(reply);
    } catch (error) {
      console.error("AI Error:", error);
      setMessages((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: "ai",
          content: "⚠️ Sorry, I’m having trouble responding right now.",
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const speak = (text) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1;
    utterance.pitch = 1.1;
    speechSynthesis.speak(utterance);
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-blue-50 to-indigo-100 relative">
      {/* Sticky Header */}
      <div className="sticky top-0 z-10 bg-white/90 backdrop-blur border-b shadow-sm py-3 px-6 flex justify-between items-center">
        <h2 className="text-xl font-semibold text-indigo-700 flex items-center gap-2">
          💬 MindGuard AI Chat
        </h2>
        {loading && <LoadingSpinner />}
      </div>

      {/* Chat Scroll Container */}
      <div
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto px-4 py-6 space-y-4 scroll-smooth pt-4"
      >
        {messages.map((msg) => (
          <ChatBox
            key={msg.id}
            message={msg.content}
            isUser={msg.role === "user"}
            emotion={msg.emotion}
            timestamp={msg.timestamp}
            voice_url={msg.voice_url || null}
            isTyping={false}
          />
        ))}

        {loading && (
          <motion.div
            className="text-center text-gray-400 text-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <span className="dot-flashing mx-auto block w-fit" />
          </motion.div>
        )}
      </div>

      {/* Input Field */}
      <form
        onSubmit={handleUserSubmit}
        className="w-full p-4 bg-white border-t flex gap-3 shadow-inner"
      >
        <input
          type="text"
          placeholder="Ask anything..."
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          className="flex-1 px-4 py-2 rounded-lg border shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
        />
        <button
          type="submit"
          disabled={loading}
          className={`px-5 py-2 rounded-lg text-white font-medium transition-all ${
            loading
              ? "bg-indigo-300 cursor-not-allowed"
              : "bg-indigo-600 hover:bg-indigo-700"
          }`}
        >
          Send
        </button>
      </form>

      {/* Mood Check-In */}
      {showMoodPopup && (
        <MoodPopup onClose={() => setShowMoodPopup(false)} />
      )}

      {/* Crisis Mode */}
      {crisisMode && <CrisisLockdown />}
    </div>
  );
};

export default Chat;
