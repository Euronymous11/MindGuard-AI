import React, { useEffect, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  Legend
} from "recharts";
import { motion } from "framer-motion";
import axios from "axios";

const MoodTrendGraph = () => {
  const [trendData, setTrendData] = useState([]);

  useEffect(() => {
    const dummyData = [
      { date: "2025-05-06", avg_mood: 3 },
      { date: "2025-05-07", avg_mood: 4 },
      { date: "2025-05-08", avg_mood: 4 },
      { date: "2025-05-09", avg_mood: 5 },
      { date: "2025-05-10", avg_mood: 4 },
      { date: "2025-05-11", avg_mood: 4 },
      { date: "2025-05-12", avg_mood: 5 },
    ];

    setTrendData(dummyData);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="p-4 rounded-lg bg-white shadow-md"
    >
      <h3 className="text-lg font-semibold mb-4">📊 Weekly Mood Trend</h3>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={trendData}>
          <defs>
            <linearGradient id="moodColor" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8} />
              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.1} />
            </linearGradient>
          </defs>

          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis domain={[0, 5]} />
          <Tooltip
            content={({ payload }) =>
              payload?.[0] ? (
                <div className="p-2 bg-white text-xs rounded shadow text-gray-800">
                  <p><strong>{payload[0].payload.date}</strong></p>
                  <p>Mood Score: {payload[0].payload.avg_mood}/5</p>
                </div>
              ) : null
            }
          />
          <Legend />
          <Area
            type="monotone"
            dataKey="avg_mood"
            stroke="#3b82f6"
            fill="url(#moodColor)"
            strokeWidth={2}
            activeDot={{ r: 6 }}
          />
          <Line
            type="monotone"
            dataKey="avg_mood"
            stroke="#3b82f6"
            strokeWidth={2}
            dot={{ r: 5, fill: "#3b82f6", stroke: "#1e40af", strokeWidth: 2 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </motion.div>
  );
};

export default MoodTrendGraph;
