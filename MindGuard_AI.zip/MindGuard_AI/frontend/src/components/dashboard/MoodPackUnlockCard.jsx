import React, { useEffect } from "react";
import confetti from "canvas-confetti";
import { motion } from "framer-motion";
import { Gift, Flame, SmilePlus } from "lucide-react";

const MoodPackUnlockCard = () => {
  const dummyStreak = 12;
  const dummyTopEmotion = "calm";

  useEffect(() => {
    if (dummyStreak >= 7) {
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
      });
    }
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className="w-full h-full bg-gradient-to-br from-emerald-50 to-emerald-100 border border-green-200 rounded-xl shadow-md p-6 flex flex-col items-center justify-center text-center"
    >
      <div className="flex items-center gap-2 text-xl font-bold text-green-700 mb-2 animate-pulse">
        <Gift className="w-6 h-6 text-green-600" />
        Mood Pack Unlocked!
      </div>

      <h3 className="text-base text-green-800 font-semibold mb-1">
        🎉 You’ve unlocked the{" "}
        <span className="underline underline-offset-2">Calm Mindset Pack</span>
      </h3>

      <p className="text-sm text-gray-700 max-w-sm mb-4">
        Thanks to your <strong>{dummyStreak}-day</strong> mood streak and{" "}
        <strong>{dummyTopEmotion}</strong> emotional pattern, you’ve earned this reward.
      </p>

      <div className="flex flex-wrap justify-center gap-4 w-full max-w-xs mb-5">
        <div className="bg-white rounded-full px-5 py-3 shadow-md flex flex-col items-center w-28">
          <Flame className="w-5 h-5 text-orange-500 mb-1" />
          <p className="text-xs text-gray-500">Streak: {dummyStreak}</p>
        </div>
        <div className="bg-white rounded-full px-5 py-3 shadow-md flex flex-col items-center w-28">
          <SmilePlus className="w-5 h-5 text-teal-500 mb-1" />
          <p className="text-xs text-gray-500">Emotion: {dummyTopEmotion}</p>
        </div>
      </div>

      <button
        className="mt-2 px-5 py-2 bg-green-600 text-white rounded-full hover:bg-green-700 transition active:scale-95"
        onClick={() => alert("Redirect to Calm Pack...")}
      >
        🎁 Explore Pack
      </button>
    </motion.div>
  );
};

export default MoodPackUnlockCard;
