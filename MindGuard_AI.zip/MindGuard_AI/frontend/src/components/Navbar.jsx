// src/components/Navbar.jsx

import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  LogOut,
  Activity,
  MessageSquare,
  Bell,
  Smile,
  User,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { motion } from "framer-motion";

const Navbar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const isActive = (path) => location.pathname === path;

  const handleLogout = () => {
    localStorage.removeItem("auth_token");
    navigate("/");
  };

  const getUserInitials = () => {
    const name = localStorage.getItem("name") || "U";
    return name.slice(0, 2).toUpperCase();
  };

  const getMoodEmoji = () => {
    const score = parseInt(localStorage.getItem("mood_score"));
    if (score >= 5) return "😄";
    if (score === 4) return "🙂";
    if (score === 3) return "😐";
    if (score === 2) return "😕";
    if (score === 1) return "😞";
    return "🧠";
  };

  const avatar = localStorage.getItem("avatar");
  const avatarFallback = "/avatar-default.png";

  return (
    <nav className="bg-white shadow-md p-4 px-6 flex items-center justify-between sticky top-0 z-50 border-b">
      <div
        onClick={() => navigate("/dashboard")}
        className="text-2xl font-bold text-blue-600 tracking-wide cursor-pointer"
      >
        MindGuard AI
      </div>

      <div className="flex items-center space-x-6">
        {/* Dashboard */}
        <Link
          to="/dashboard"
          className={`flex items-center gap-1 transition hover:text-blue-600 ${
            isActive("/dashboard") ? "text-blue-600 font-semibold" : "text-gray-600"
          }`}
        >
          <Activity size={18} />
          Dashboard
        </Link>

        {/* Chat */}
        <Link
          to="/chat"
          className={`flex items-center gap-1 transition hover:text-blue-600 ${
            isActive("/chat") ? "text-blue-600 font-semibold" : "text-gray-600"
          }`}
        >
          <MessageSquare size={18} />
          Chat
        </Link>

        {/* Mood */}
        <motion.div
          className="text-xl"
          title="Last Mood Check-In"
          whileHover={{ scale: 1.3 }}
        >
          <Smile className="inline-block mr-1 text-yellow-500" />
          {getMoodEmoji()}
        </motion.div>

        {/* Notifications */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          className="relative text-gray-500 hover:text-blue-600"
          title="Notifications"
        >
          <Bell className="w-5 h-5" />
          <span className="absolute -top-1 -right-1 h-2 w-2 bg-red-500 rounded-full animate-ping" />
        </motion.button>

        {/* Avatar */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <motion.div
              whileTap={{ scale: 0.95 }}
              title="Go to Profile"
              className="cursor-pointer"
            >
              <img
                src={avatar || avatarFallback}
                alt="Avatar"
                className="h-9 w-9 rounded-full object-cover shadow-sm hover:shadow-md"
              />
            </motion.div>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="mt-2 w-44">
            <DropdownMenuItem onClick={() => navigate("/profile")}>
              <User className="mr-2 h-4 w-4" /> Profile
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout} className="text-red-500">
              <LogOut className="mr-2 h-4 w-4" /> Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </nav>
  );
};

export default Navbar;
