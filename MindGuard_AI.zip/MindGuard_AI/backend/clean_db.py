from app.db.session import engine
from app.db.base import base
from app.models import session_summary

Base.metadata.drop_all(bind=engine)
Base.metadata.create_all(bind=engine)
