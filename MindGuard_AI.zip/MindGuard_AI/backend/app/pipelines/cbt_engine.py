import re
from typing import Dict, List

COGNITIVE_PATTERNS = {
    "all_or_nothing": r"\b(always|never|completely|totally|entirely|no one|everyone)\b",
    "catastrophizing": r"\b(ruined|disaster|horrible|terrible|unbearable|worst case)\b",
    "mind_reading": r"\b(they think|everyone thinks|they hate me|they must believe)\b",
    "overgeneralization": r"\b(nothing ever|everything always|this always happens|i never)\b",
    "emotional_reasoning": r"\b(i feel (worthless|stupid|hopeless|like a failure))\b",
    "labeling": r"\b(i’m (a failure|a loser|worthless|stupid))\b",
    "should_statements": r"\b(should have|must do|need to|ought to)\b",
}

CBT_REFRAMES = {
    "all_or_nothing": "Try to see the shades of grey—situations are rarely all good or all bad.",
    "catastrophizing": "Consider the actual likelihood and think about how you’ve coped in the past.",
    "mind_reading": "You can’t be sure what others think—try to ask or challenge that assumption.",
    "overgeneralization": "Focus on this situation alone. What happened here specifically?",
    "emotional_reasoning": "Feelings aren't facts. Look for objective evidence instead.",
    "labeling": "Try describing the behavior instead of labeling your entire self.",
    "should_statements": "Replace 'should' with 'could' to reduce guilt and pressure.",
}

def detect_distortions(text: str) -> List[str]:
    return [
        key
        for key, pattern in COGNITIVE_PATTERNS.items()
        if re.search(pattern, text, re.IGNORECASE)
    ]

def suggest_reframe(distortions: List[str], original_text: str) -> str:
    if not distortions:
        return "No major distortions found. Reflecting on your thoughts is a great first step."
    responses = [CBT_REFRAMES.get(d, "") for d in distortions]
    return " ".join(responses)

def run_cbt_pipeline(text: str) -> Dict[str, List[str]]:
    distortions = detect_distortions(text)
    reframes = [CBT_REFRAMES[d] for d in distortions if d in CBT_REFRAMES]
    return {"distortions": distortions, "reframes": reframes}
