import os
from openai import OpenAI
from app.core.logger import logger

# Initialize the OpenAI client using the environment variable
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


def generate_weekly_summary(chat_history: list[dict]) -> str:
    try:
        # Format the chat messages
        formatted = "\n".join(
            [f"User: {c['message']}\nAI: {c['response']}" for c in chat_history]
        )

        # Prepare prompt
        prompt = (
            "Summarize this weekly emotional chat history. Include key emotional themes, mood swings, and possible improvement opportunities:\n\n"
            + formatted
        )

        # Use new SDK call
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=500,
            temperature=0.6,
        )

        return response.choices[0].message.content.strip()

    except Exception as e:
        logger.error(f"Error generating weekly summary: {e}")
        return "Summary unavailable due to an error."
