import uuid
from uuid import uuid4
from datetime import datetime
from sqlalchemy import (
    Column,
    String,
    Integer,
    DateTime,
    Boolean,
    Float,
    Text,
    ForeignKey,
    JSON,
    ARRAY,
)
from sqlalchemy.dialects.postgresql import UUID
from app.db.base import Base


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    password = Column(String(128), nullable=False)
    emergency_name = Column(String(100), nullable=True)
    emergency_email = Column(String(100), nullable=True)
    emergency_phone = Column(String(20), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class Chat(Base):
    __tablename__ = "chats"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    user_id = Column(String, nullable=False)
    message = Column(Text)
    response = Column(Text)
    sentiment = Column(String)
    emotion = Column(JSON)  # ✅ correct type for emotion
    risk_score = Column(Integer)
    distortions = Column(JSON)
    reframe = Column(Text)
    coaching_tip = Column(Text)
    is_flagged = Column(Boolean, default=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    mood = Column(String)
    risk = Column(Text)
    is_journal = Column(Boolean, default=False)
    role = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

class Mood(Base):
    __tablename__ = "moods"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    mood = Column(String(30), nullable=False)
    mood_score = Column(Integer, default=3, nullable=False)
    mood_date = Column(DateTime, default=datetime.utcnow, nullable=False)


class Badge(Base):
    __tablename__ = "badges"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    badge_name = Column(String(100), nullable=False)
    badge_type = Column(String(50), nullable=False)
    achieved_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class PsychometricTest(Base):
    __tablename__ = "psychometric_tests"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    test_type = Column(String(50), nullable=False)
    score = Column(Integer, nullable=False)
    level = Column(String(30), nullable=False)
    interpretation = Column(Text, nullable=False)
    submitted_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class SessionSummary(Base):
    __tablename__ = "session_summaries"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    summary = Column(String(1000), nullable=False)
    avg_mood = Column(Integer, default=3, nullable=False)
    avg_risk = Column(Integer, default=0, nullable=False)
    top_emotions = Column(ARRAY(String), default=[], nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    last_updated = Column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )


class RiskAssessment(Base):
    __tablename__ = "risk_assessments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    risk_score = Column(Float, nullable=False)
    mood_score = Column(Float, nullable=False)
    emotion_score = Column(Float, nullable=False)
    risk_level = Column(String(30), nullable=False)
    advice = Column(Text, nullable=False)
    assessed_at = Column(DateTime, default=datetime.utcnow, nullable=False)
