# app/api/v1/__init__.py

from .routes import router as api_router
