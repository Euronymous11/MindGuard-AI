// src/components/chat/MoodPopup.jsx

import React, { useState } from "react";
import api from "@/lib/axios"; // ✅ Configured Axios instance
import useConfetti from "@/utils/useConfetti"; // ✅ Confetti for celebration

const moods = [
  { score: 1, label: "😞" },
  { score: 2, label: "😕" },
  { score: 3, label: "😐" },
  { score: 4, label: "🙂" },
  { score: 5, label: "😄" },
];

const MoodPopup = ({ onClose = () => {}, onSubmit = () => {} }) => {
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const launchConfetti = useConfetti();

  const submitMood = async () => {
    if (!selected) return;

    try {
      await api.post("/mood/submit", { mood_score: selected });
      setSubmitted(true);
      launchConfetti();      // 🎉 celebrate
      onSubmit(selected);    // 📦 pass mood to parent
      setTimeout(onClose, 1500);
    } catch (err) {
      console.error("❌ Mood submission failed:", err);
      onClose(); // fallback close
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg text-center shadow-2xl max-w-sm w-full">
        <h2 className="text-xl font-semibold mb-4 text-gray-700">
          How are you feeling today?
        </h2>
        <div className="flex justify-center gap-4 text-3xl">
          {moods.map((m) => (
            <button
              key={m.score}
              onClick={() => setSelected(m.score)}
              className={`p-2 rounded-full transition-all hover:scale-110 ${
                selected === m.score ? "ring-4 ring-blue-400" : ""
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>
        <button
          onClick={submitMood}
          disabled={!selected}
          className={`mt-6 w-full py-2 rounded font-medium transition-all ${
            selected
              ? "bg-blue-600 text-white hover:bg-blue-700"
              : "bg-gray-300 text-gray-500 cursor-not-allowed"
          }`}
        >
          Submit
        </button>
      </div>
    </div>
  );
};

export default MoodPopup;
