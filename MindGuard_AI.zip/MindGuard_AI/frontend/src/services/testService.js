import axios from "axios";

const API_URL = "/api/v1/test";

const submitTest = async (data) => {
  const token = localStorage.getItem("token");
  const res = await axios.post(`${API_URL}/submit`, data, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data;
};

const getTestHistory = async () => {
  const token = localStorage.getItem("token");
  const res = await axios.get(`${API_URL}/history`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data;
};

export default { submitTest, getTestHistory };
