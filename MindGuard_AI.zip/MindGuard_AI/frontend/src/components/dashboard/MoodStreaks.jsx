import React, { useEffect, useState } from "react";
import confetti from "canvas-confetti";
import { motion } from "framer-motion";

const MoodStreaks = () => {
  const [streak, setStreak] = useState(0);

  useEffect(() => {
    // Dummy streak for test user mode
    const dummyStreak = 5;
    setStreak(dummyStreak);

    if (dummyStreak >= 3) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  }, []);

  const percentage = Math.min((streak / 7) * 100, 100);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6 }}
      className="bg-green-100 p-5 rounded-lg text-center shadow-md relative"
    >
      <h3 className="text-lg font-bold mb-2">🌟 Mood Streak</h3>

      <div className="relative inline-block mb-2">
        {/* Animated glow number */}
        <p className="text-4xl font-extrabold text-green-800 animate-pulse">{streak} days</p>

        {/* Optional visual ring */}
        <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center">
          <svg className="w-16 h-16">
            <circle
              cx="32"
              cy="32"
              r="28"
              stroke="#a7f3d0"
              strokeWidth="5"
              fill="none"
              className="opacity-30"
            />
            <circle
              cx="32"
              cy="32"
              r="28"
              stroke="#047857"
              strokeWidth="5"
              fill="none"
              strokeDasharray={2 * Math.PI * 28}
              strokeDashoffset={2 * Math.PI * 28 * (1 - percentage / 100)}
              strokeLinecap="round"
              transform="rotate(-90 32 32)"
              className="transition-all duration-700"
            />
          </svg>
        </div>
      </div>

      <p className="text-sm text-green-900">of feeling positive!</p>
    </motion.div>
  );
};

export default MoodStreaks;
