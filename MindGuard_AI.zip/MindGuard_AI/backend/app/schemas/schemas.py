from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import date, datetime

# -------------------- CHAT --------------------
class ChatRequest(BaseModel):
    message: str = Field(..., example="I feel anxious today")
    is_journal: Optional[bool] = False

class ChatResponse(BaseModel):
    reply: str
    sentiment: Optional[str] = None
    emotion: Optional[str] = None
    risk: Optional[str] = None
    summary: Optional[str] = None

# -------------------- MOOD --------------------
class MoodCreate(BaseModel):
    mood: str
    emotion: Optional[str] = None
    mood_score: int = Field(..., ge=1, le=10)

class Mood(BaseModel):
    id: str
    user_id: str
    mood: str
    mood_score: int
    mood_date: date

    class Config:
        from_attributes = True

class WeeklyTrend(BaseModel):
    daily_scores: List[int]
    average_score: float

# -------------------- SUMMARY --------------------
class WeeklySummary(BaseModel):
    id: str
    user_id: str
    summary: str
    avg_mood: Optional[int] = None
    avg_risk: Optional[int] = None
    top_emotions: Optional[dict] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class SessionSummaryCreate(BaseModel):
    user_id: str
    summary: str
    avg_mood: Optional[int]
    avg_risk: Optional[int]
    top_emotions: Optional[dict]

# -------------------- BADGES --------------------
class BadgeRequest(BaseModel):
    badge_name: str

class BadgeOut(BaseModel):
    id: str
    user_id: str
    badge_name: str
    awarded_on: datetime

    class Config:
        from_attributes = True

# -------------------- PSYCHOMETRIC TEST --------------------
class PHQ9Request(BaseModel):
    scores: List[int] = Field(..., min_items=9, max_items=9)

class GAD7Request(BaseModel):
    scores: List[int] = Field(..., min_items=7, max_items=7)

class PsychometricTestOut(BaseModel):
    id: str
    user_id: str
    test_type: str
    scores: List[int]
    interpretation: str
    submitted_at: datetime

    class Config:
        from_attributes = True

# -------------------- USER --------------------
class UserOut(BaseModel):
    id: str
    email: EmailStr
    username: str
    emergency_contact: Optional[str] = None

    class Config:
        from_attributes = True

# -------------------- RISK --------------------
class RiskAssessmentResult(BaseModel):
    risk_score: int
    risk_level: str

class RiskAssessmentIn(BaseModel):
    user_id: str
    risk_score: int
    risk_level: str

# -------------------- COACHING --------------------
class CoachingTip(BaseModel):
    tip: str
    focus_area: str
