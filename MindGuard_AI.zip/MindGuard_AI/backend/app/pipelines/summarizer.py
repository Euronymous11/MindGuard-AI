# app/pipelines/summarizer.py

import logging

from openai import OpenAI, OpenAIError

from app.core.config import settings

logger = logging.getLogger(__name__)

client = OpenAI(api_key=settings.OPENAI_API_KEY)


def generate_session_summary(chat_log: list) -> str:
    """
    Generate a session summary from a chat log using OpenAI's LLM.
    """
    if not chat_log or not isinstance(chat_log, list):
        logger.warning("Empty or invalid chat_log input to generate_session_summary")
        return "No session data available for summarization."

    try:
        prompt_lines = [
            "Summarize this therapy-style chat session with insights into:",
            "- Mood progression",
            "- Emotional fluctuations",
            "- Risk signals (if any)",
            "- Notable journaling thoughts\n",
        ]
        for msg in chat_log:
            if "user" in msg:
                prompt_lines.append(f"User: {msg['user']}")
            elif "ai" in msg:
                prompt_lines.append(f"AI: {msg['ai']}")
        prompt = "\n".join(prompt_lines)

        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=300,
        )

        summary = response.choices[0].message.content.strip()
        logger.info("Session summary generated.")
        return summary

    except OpenAIError as e:
        logger.error(f"OpenAI session summarization failed: {str(e)}")
        return "Summary generation encountered an error."
