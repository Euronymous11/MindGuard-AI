import React from "react";
import { BrowserRouter as Router, useLocation } from "react-router-dom";
import AppRouter from "@/router";
import Navbar from "@/components/layout/Navbar";

function Layout() {
  const location = useLocation();
  const hideNavbarRoutes = ["/", "/login"]; // Add more routes as needed
  const shouldHideNavbar = hideNavbarRoutes.includes(location.pathname);

  return (
    <>
      {!shouldHideNavbar && <Navbar />}
      <div className={shouldHideNavbar ? "" : "pt-16"}>
        <AppRouter />
      </div>
    </>
  );
}

export default function App() {
  return (
    <Router>
      <Layout />
    </Router>
  );
}
