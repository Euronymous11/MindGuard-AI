from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.v1.routes import api_router
from app.core.config import settings
from app.core.logger import logger
from app.db.session import engine
from app.db.base import Base

Base.metadata.drop_all(bind=engine)     # <== Drops all tables
Base.metadata.create_all(bind=engine)   # <== Recreates them based on models


app = FastAPI(title="MindGuard AI", version="1.0.0")

# CORS settings
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create all tables
Base.metadata.create_all(bind=engine)

# Include unified router
app.include_router(api_router)

logger.info("🚀 MindGuard AI backend is up and running")
