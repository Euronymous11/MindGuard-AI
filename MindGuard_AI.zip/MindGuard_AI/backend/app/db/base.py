# backend/app/db/base.py

from sqlalchemy.orm import declarative_base

from app.db.session import SessionLocal

Base = declarative_base()


def get_db():
    """
    Dependency for FastAPI routes.
    Yields a SQLAlchemy Session, and ensures it's closed after use.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
