import React, { useEffect, useState } from "react";
import {
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { motion } from "framer-motion";
import axios from "axios";

const EmotionRadarChart = () => {
  const [emotionData, setEmotionData] = useState([]);

  const dummyEmotions = [
    { emotion: "happy", value: 4 },
    { emotion: "sad", value: 2 },
    { emotion: "angry", value: 1 },
    { emotion: "calm", value: 5 },
    { emotion: "surprised", value: 3 },
    { emotion: "fearful", value: 2 },
  ];

  useEffect(() => {
    setEmotionData(dummyEmotions);

    // Uncomment for backend data later
    /*
    const fetchEmotionData = async () => {
      const token = localStorage.getItem("token");
      try {
        const res = await axios.get("/api/v1/chat/emotion-frequencies", {
          headers: { Authorization: `Bearer ${token}` },
        });

        const safeArray = Array.isArray(res.data)
          ? res.data
          : Array.isArray(res.data.data)
          ? res.data.data
          : [];

        setEmotionData(safeArray);
      } catch (err) {
        console.error("❌ Error fetching emotion radar data", err);
        setEmotionData([]);
      }
    };

    fetchEmotionData();
    */
  }, []);

  const topEmotion = emotionData.reduce((a, b) => (a.value > b.value ? a : b), {});

  return (
    <motion.div
      initial={{ opacity: 0, y: 25 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="p-4 rounded-lg bg-white shadow-md relative"
    >
      <h3 className="text-lg font-semibold mb-4 flex items-center justify-between">
        🎯 Emotion Frequency
        {topEmotion?.emotion && (
          <div className="text-xs bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full shadow-md animate-pulse">
            Top Emotion: {topEmotion.emotion} 💬
          </div>
        )}
      </h3>

      {emotionData.length > 0 ? (
        <ResponsiveContainer width="100%" height={300}>
          <RadarChart outerRadius="80%" width={500} height={300} data={emotionData}>
            <PolarGrid />
            <PolarAngleAxis dataKey="emotion" />
            <PolarRadiusAxis />
            <Tooltip
              content={({ payload }) =>
                payload?.[0] ? (
                  <div className="bg-white text-xs p-2 rounded shadow">
                    {payload[0].payload.emotion}: {payload[0].payload.value}
                  </div>
                ) : null
              }
            />
            <Radar
              name="Emotion"
              dataKey="value"
              stroke="#6366f1"
              fill="#c7d2fe"
              fillOpacity={0.5}
            />
          </RadarChart>
        </ResponsiveContainer>
      ) : (
        <p className="text-gray-500 text-sm italic">No emotion data available.</p>
      )}
    </motion.div>
  );
};

export default EmotionRadarChart;
