import React from "react";
import { AlertTriangle, CheckCircle, Circle } from "lucide-react";
import moment from "moment";
import { motion } from "framer-motion";

const RiskTimeline = ({
  data = [
    {
      date: "2025-05-01T09:00:00",
      level: 3,
      note: "Slight concern about upcoming exams.",
    },
    {
      date: "2025-05-03T14:20:00",
      level: 6,
      note: "Expressed feeling overwhelmed by tasks.",
    },
    {
      date: "2025-05-05T18:45:00",
      level: 9,
      note: "High emotional stress after personal conflict.",
    },
  ],
}) => {
  if (!Array.isArray(data) || data.length === 0) {
    return (
      <div className="text-center text-gray-500 mt-4">
        No risk events have been logged yet.
      </div>
    );
  }

  const getRiskIcon = (level) => {
    if (level >= 8) return <AlertTriangle className="text-red-600 animate-bounce" />;
    if (level >= 5) return <Circle className="text-yellow-500" />;
    return <CheckCircle className="text-green-600" />;
  };

  const getRiskLabel = (level) => {
    if (level >= 8) return "High Risk";
    if (level >= 5) return "Moderate Risk";
    return "Low Risk";
  };

  const getRiskColor = (level) => {
    if (level >= 8) return "border-red-500";
    if (level >= 5) return "border-yellow-400";
    return "border-green-400";
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="mt-6 bg-white rounded-lg shadow-md p-6"
    >
      <h2 className="text-lg font-semibold mb-4">🧠 Risk Escalation Timeline</h2>

      <div className="space-y-4">
        {data.map((entry, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`flex items-start gap-4 border-l-4 pl-4 ${getRiskColor(entry.level)} bg-gray-50 rounded-md p-3`}
            title={`Recorded: ${moment(entry.date).format("MMMM Do YYYY, h:mm A")}`}
          >
            <div className="pt-1">{getRiskIcon(entry.level)}</div>
            <div>
              <p className="font-medium">
                {getRiskLabel(entry.level)} – <span className="text-gray-600">{entry.level}/10</span>
              </p>
              <p className="text-sm text-gray-500">
                {moment(entry.date).format("MMM D, YYYY h:mm A")}
              </p>
              {entry.note && (
                <p className="text-sm text-gray-700 mt-1 italic">"{entry.note}"</p>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default RiskTimeline;
