import React from "react";
import { motion } from "framer-motion";
import { CalendarDays, Smile, Frown, Meh, Laugh, Angry } from "lucide-react";

const dummyMoodData = [
  { date: "2025-05-01", mood: 4, note: "Felt relaxed after walk." },
  { date: "2025-05-02", mood: 3, note: "Just okay today." },
  { date: "2025-05-03", mood: 2, note: "A bit stressed." },
  { date: "2025-05-04", mood: 5, note: "Super productive!" },
  { date: "2025-05-05", mood: 1, note: "Overwhelmed by deadlines." },
  { date: "2025-05-06", mood: 4, note: "Had good conversations." },
  { date: "2025-05-07", mood: 3, note: "Neutral day overall." },
  { date: "2025-05-12", mood: 5, note: "Felt optimistic and productive." },
];

const getMoodIcon = (mood) => {
  if (mood >= 5) return <Laugh className="text-green-500" />;
  if (mood === 4) return <Smile className="text-blue-500" />;
  if (mood === 3) return <Meh className="text-gray-500" />;
  if (mood === 2) return <Frown className="text-yellow-500" />;
  return <Angry className="text-red-500" />;
};

const getMoodColor = (mood) => {
  if (mood >= 5) return "border-green-400";
  if (mood === 4) return "border-blue-400";
  if (mood === 3) return "border-gray-400";
  if (mood === 2) return "border-yellow-400";
  return "border-red-400";
};

const MoodTimeline = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white p-4 rounded-xl shadow-md"
    >
      <h3 className="text-lg font-bold text-blue-700 mb-3 flex items-center gap-2">
        <CalendarDays className="text-blue-500" size={20} />
        📍 Mood Timeline (Last 7 Days)
      </h3>

      <div className="flex overflow-x-auto gap-4 pb-2 scrollbar-thin scrollbar-thumb-blue-300">
        {dummyMoodData.map((item, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`min-w-[160px] border-l-4 ${getMoodColor(
              item.mood
            )} bg-gradient-to-br from-blue-50 to-blue-100 rounded-md shadow-sm px-4 py-3`}
          >
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-semibold text-gray-700">
                {new Date(item.date).toLocaleDateString()}
              </span>
              {getMoodIcon(item.mood)}
            </div>
            <p className="text-gray-600 text-xs italic">{item.note}</p>
            <p className="text-sm text-right text-blue-700 mt-2 font-bold">
              Mood: {item.mood}/5
            </p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default MoodTimeline;
