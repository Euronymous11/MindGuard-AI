import React from "react";
import { motion } from "framer-motion";
import { Sparkles, CalendarCheck, Flame, BookOpen, Smile, Award } from "lucide-react";

const wellnessInsights = [
  {
    icon: <Smile className="text-yellow-500" />,
    label: "Average Mood",
    value: "4.2 / 5",
  },
  {
    icon: <Sparkles className="text-purple-500" />,
    label: "Top Emotion",
    value: "Calm",
  },
  {
    icon: <BookOpen className="text-blue-500" />,
    label: "Journal Entries",
    value: "5 entries",
  },
  {
    icon: <Flame className="text-red-500" />,
    label: "Streak",
    value: "6 days 🔥",
  },
  {
    icon: <Award className="text-green-600" />,
    label: "Badge Earned",
    value: "📝 Micro-Journalist",
  },
  {
    icon: <CalendarCheck className="text-indigo-600" />,
    label: "Weekly Score",
    value: "87%",
  },
];

const WellnessCarousel = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 25 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white rounded-xl shadow-md p-4 overflow-x-auto whitespace-nowrap"
    >
      <h3 className="text-lg font-bold mb-3 text-blue-700">📅 Weekly Wellness Highlights</h3>
      <div className="flex gap-4 overflow-x-scroll pb-2 scrollbar-thin scrollbar-thumb-blue-300">
        {wellnessInsights.map((item, index) => (
          <motion.div
            key={index}
            className="min-w-[200px] bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-lg px-4 py-3 shadow-sm hover:shadow-md transition"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <div className="flex items-center gap-2 mb-2">{item.icon}<span className="font-medium text-sm">{item.label}</span></div>
            <div className="text-md font-bold text-gray-800">{item.value}</div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default WellnessCarousel;
