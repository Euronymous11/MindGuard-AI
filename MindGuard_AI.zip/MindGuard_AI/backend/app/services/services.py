# services.py — Part 1/3: Imports, ChatService, MoodService

import json
from uuid import uuid4

from datetime import date, datetime
from typing import Optional, List, Dict, Any
from sqlalchemy.orm import Session
from fastapi import HTTPException
from app.models import Chat, Mood, SessionSummary, Badge
from app.schemas import ChatRequest, MoodCreate
from app.utils.analyzer import analyze_text
from app.utils.ai_generator import get_ai_response
#from app.utils.cbt_engine import 
from app.utils.coaching import get_coaching_tip
from app.pipelines.ras import calculate_risk, calculate_mood_score
from app.pipelines.summarizer import generate_session_summary
from app.pipelines.weekly_summary import generate_weekly_summary
from app.pipelines.cbt_engine import detect_distortions,suggest_reframe,run_cbt_pipeline
from app.core.logger import logger

# ---------------------- Chat Service ----------------------

def process_message(db: Session, request: ChatRequest) -> Dict[str, Any]:
    analysis = analyze_text(request.message)
    ai_reply = get_ai_response(request.message)

    new_chat = Chat(
        id=uuid4(),
        user_id="demo",
        message=request.message,
        response=ai_reply,
        sentiment=analysis.get("sentiment"),
        emotion=json.dumps(analysis.get("emotion")),
        risk_score=analysis.get("risk_score"),
        mood=analysis.get("mood"),
        is_journal=request.is_journal,
        role="user",
        timestamp=datetime.utcnow(),
        created_at=datetime.utcnow()
    )

    db.add(new_chat)
    db.commit()
    db.refresh(new_chat)

    logger.info(f"Processed message at {new_chat.created_at}")

    return {
        "reply": ai_reply,
        "sentiment": analysis.get("sentiment"),
        "emotion": json.dumps(analysis.get("emotion")),
        "risk_score": analysis.get("risk_score"),
        "mood": analysis.get("mood"),
    }



# ---------------------- Mood Service ----------------------

def submit_mood(db: Session, user_id: str, mood_data: MoodCreate) -> Mood:
    today = date.today()
    existing = db.query(Mood).filter(Mood.user_id == user_id, Mood.mood_date == today).first()

    if existing:
        logger.warning(f"Mood already submitted for user {user_id} on {today}")
        raise HTTPException(status_code=400, detail="Mood already submitted for today.")

    mood_entry = Mood(
        user_id=user_id,
        mood_score=mood_data.mood_score,
        emotion=mood_data.emotion,
        mood_date=today,
        created_at=datetime.utcnow()
    )
    db.add(mood_entry)
    db.commit()
    db.refresh(mood_entry)

    logger.info(f"Mood logged: {mood_entry}")
    return mood_entry

# ✅ Add this function at the bottom of services.py

def get_all_moods(db: Session, user_id: str) -> List[Mood]:
    moods = db.query(Mood).filter(Mood.user_id == user_id).order_by(Mood.mood_date.desc()).all()
    logger.debug(f"Retrieved {len(moods)} mood entries for user {user_id}")
    return moods


# services.py — Part 2/3: Summary, Weekly Summary, Badge Services

# ---------------------- Session Summary Service ----------------------

def create_session_summary(
    db: Session,
    user_id: str,
    chats: List[Dict[str, Any]]
) -> SessionSummary:
    if not chats:
        raise HTTPException(status_code=400, detail="No chats provided for summary.")

    summary_text = generate_session_summary(chats)
    avg_mood = int(sum([c.get("mood_score", 0) for c in chats]) / len(chats))
    avg_risk = int(sum([c.get("risk_score", 0) for c in chats]) / len(chats))
    top_emotions = {
        e: sum(1 for c in chats if c.get("emotion") == e)
        for e in set(c.get("emotion") for c in chats)
    }

    summary_entry = SessionSummary(
        user_id=user_id,
        summary=summary_text,
        avg_mood=avg_mood,
        avg_risk=avg_risk,
        top_emotions=top_emotions,
        created_at=datetime.utcnow(),
        last_updated=datetime.utcnow()
    )
    db.add(summary_entry)
    db.commit()
    db.refresh(summary_entry)

    logger.info(f"Session summary created for user {user_id}")
    return summary_entry

def get_latest_summary(db: Session, user_id: str) -> Optional[SessionSummary]:
    return db.query(SessionSummary).filter(SessionSummary.user_id == user_id).order_by(
        SessionSummary.created_at.desc()
    ).first()

# ---------------------- Weekly Summary Service ----------------------

def get_weekly_report(db: Session, user_id: str) -> Dict[str, Any]:
    chats = db.query(Chat).filter(Chat.user_id == user_id).all()
    chat_log = [{"message": c.message, "response": c.response} for c in chats]

    summary = generate_weekly_summary(chat_log)
    logger.info(f"Generated weekly report for user {user_id}")
    return {"user_id": user_id, "weekly_summary": summary}

# ✅ Add to services.py if used
def create_weekly_summary(db: Session, user_id: str) -> SessionSummary:
    messages = db.query(Chat).filter(Chat.user_id == user_id).all()
    formatted = [{"message": m.message, "response": m.response} for m in messages]
    summary_data = generate_weekly_summary(formatted)
    summary = SessionSummary(user_id=user_id, **summary_data)
    db.add(summary)
    db.commit()
    db.refresh(summary)
    return summary


# ---------------------- Badge Service ----------------------

def evaluate_badges(db: Session, user_id: str) -> List[Badge]:
    badges_awarded = []

    mood_entries = db.query(Mood).filter(Mood.user_id == user_id).order_by(Mood.mood_date).all()
    if not mood_entries:
        return badges_awarded

    streak = 1
    last_date = mood_entries[0].mood_date

    for entry in mood_entries[1:]:
        if (entry.mood_date - last_date).days == 1:
            streak += 1
        else:
            streak = 1
        last_date = entry.mood_date

    if streak >= 7:
        badge = Badge(user_id=user_id, name="7-Day Streak", description="Maintained mood logs for 7 days.")
        db.add(badge)
        db.commit()
        db.refresh(badge)
        badges_awarded.append(badge)
        logger.info(f"Badge awarded: {badge.name} to user {user_id}")

    return badges_awarded

# services.py — Part 3/3: CBT, Coaching, Psychometric Services

# ---------------------- CBT Distortion Detection ----------------------

def detect_and_reframe(text: str) -> Dict[str, Any]:
    try:
        distortions = detect_distortions(text)
        reframe = suggest_reframe(distortions)
        return {"distortions": distortions, "reframe": reframe}
    except Exception as e:
        logger.error(f"CBT detection failed: {e}")
        raise HTTPException(status_code=500, detail="CBT detection error.")

# ---------------------- Coaching Tips Service ----------------------

def provide_coaching_tip(mood: str, emotion: str) -> str:
    try:
        tip = get_coaching_tip(mood, emotion)
        logger.info(f"Coaching tip generated for mood={mood}, emotion={emotion}")
        return tip
    except Exception as e:
        logger.warning(f"Failed to generate coaching tip: {e}")
        return "Stay mindful. Every feeling is valid. Take a deep breath."

# ---------------------- Psychometric Test Evaluation ----------------------

def evaluate_test_score(responses: List[int], test_type: str) -> Dict[str, Any]:
    total = sum(responses)
    interpretation = ""
    
    if test_type == "phq9":
        if total <= 4:
            interpretation = "Minimal depression"
        elif total <= 9:
            interpretation = "Mild depression"
        elif total <= 14:
            interpretation = "Moderate depression"
        elif total <= 19:
            interpretation = "Moderately severe depression"
        else:
            interpretation = "Severe depression"

    elif test_type == "gad7":
        if total <= 4:
            interpretation = "Minimal anxiety"
        elif total <= 9:
            interpretation = "Mild anxiety"
        elif total <= 14:
            interpretation = "Moderate anxiety"
        else:
            interpretation = "Severe anxiety"

    else:
        raise HTTPException(status_code=400, detail="Invalid test type.")

    logger.info(f"{test_type.upper()} score evaluated: {total} — {interpretation}")
    return {"score": total, "interpretation": interpretation}

# ---------------------- Evaluation Wrappers ----------------------

def evaluate_phq9(responses: List[int]) -> Dict[str, Any]:
    return evaluate_test_score(responses, test_type="phq9")

def evaluate_gad7(responses: List[int]) -> Dict[str, Any]:
    return evaluate_test_score(responses, test_type="gad7")


# ---------------------- Chat Summarization ----------------------

def summarize_chat(chats: List[Dict[str, Any]]) -> str:
    if not chats:
        raise ValueError("No chats provided for summarization.")
    return generate_session_summary(chats)


# ---------------------- Coaching & Suggestions ----------------------

def generate_recommendations(mood_score: int, top_emotions: List[str]) -> List[str]:
    tips = []
    if mood_score < 5:
        tips.append("Try a grounding exercise or short walk.")
    if "anxious" in top_emotions:
        tips.append("Practice deep breathing or meditation.")
    if "sad" in top_emotions:
        tips.append("Consider reaching out to a friend or journaling.")
    tips.append(get_coaching_tip(mood_score, top_emotions))
    return tips


# ---------------------- Mood Pattern Analyzer ----------------------

def analyze_mood(moods: List[int]) -> dict:
    if not moods:
        return {"average": 0, "trend": "no data"}
    average = sum(moods) / len(moods)
    trend = "improving" if moods[-1] > moods[0] else "declining" if moods[-1] < moods[0] else "stable"
    return {"average": round(average, 2), "trend": trend}


# ---------------------- Risk Detection ----------------------

def detect_risk(message: str) -> int:
    risk_score = calculate_risk(message)
    logger.debug(f"Detected risk score {risk_score} from message")
    return risk_score


def get_weekly_mood_trend(db: Session, user_id: str) -> dict:
    from app.pipelines.weekly_summary import generate_weekly_summary

    mood_entries = db.query(Mood).filter(Mood.user_id == user_id).all()
    if not mood_entries:
        return {"weekly_average": 0, "mood_trend": []}

    return generate_weekly_summary(mood_entries)


def detect_and_reframe(text: str) -> dict:
    """
    Uses the cognitive distortion detection pipeline to return distortions and reframes.
    """
    try:
        result = run_cbt_pipeline(text)
        return result
    except Exception as e:
        logger.error("CBT pipeline failed", exc_info=True)
        return {"distortions": [], "reframes": []}
