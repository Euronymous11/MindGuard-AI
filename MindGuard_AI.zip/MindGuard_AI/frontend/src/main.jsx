import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import AppRouter from "./router";
import "./index.css";

/**
 * ⚠️  React.StrictMode in dev intentionally double‑invokes some
 *     lifecycle hooks. To avoid duplicate API calls (e.g. in Chat),
 *     we mount the app **once** outside StrictMode.
 *
 *     If you prefer StrictMode, wrap <AppRouter /> with it
 *     and make sure your side‑effects are idempotent.
 */
ReactDOM.createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <AppRouter />
  </BrowserRouter>
);
