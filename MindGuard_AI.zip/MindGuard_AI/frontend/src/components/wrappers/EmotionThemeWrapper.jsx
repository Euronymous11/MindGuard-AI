import React from "react";
import { motion } from "framer-motion";

// Dummy top emotion for now
const dummyTopEmotion = "calm";

// Tailwind background gradient mappings
const emotionThemes = {
  happy: "from-yellow-50 to-yellow-100",
  sad: "from-blue-50 to-blue-100",
  calm: "from-teal-50 to-teal-100",
  angry: "from-red-50 to-red-100",
  surprised: "from-pink-50 to-pink-100",
  neutral: "from-gray-50 to-gray-100",
};

const EmotionThemeWrapper = ({ children }) => {
  const themeGradient = emotionThemes[dummyTopEmotion] || "from-white to-white";

  return (
    <motion.div
      className={`min-h-screen bg-gradient-to-b ${themeGradient} transition-all duration-700`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {children}
      </div>
    </motion.div>
  );
};

export default EmotionThemeWrapper;
