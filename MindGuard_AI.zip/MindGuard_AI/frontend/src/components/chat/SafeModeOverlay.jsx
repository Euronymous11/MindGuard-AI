import React from "react";

const SafeModeOverlay = ({ onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded-xl shadow-xl text-center max-w-md">
        <h2 className="text-xl font-bold text-red-600 mb-3">You're Not Alone</h2>
        <p className="text-gray-700 mb-4">
          We're sensing some distress. Take a deep breath. This space is safe.
        </p>
        <div className="w-full mb-4">
          <p className="text-blue-500 font-semibold">🧘 Try box breathing:</p>
          <p className="text-sm mt-1">Inhale 4s → Hold 4s → Exhale 4s → Hold 4s</p>
        </div>
        <button
          onClick={onClose}
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Continue Chat
        </button>
      </div>
    </div>
  );
};

export default SafeModeOverlay;
