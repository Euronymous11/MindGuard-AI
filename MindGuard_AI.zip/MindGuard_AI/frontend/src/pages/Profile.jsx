// src/pages/Profile.jsx

import React, { useEffect, useState } from "react";
import {
  User, Mail, Phone, Lock, ShieldCheck, Pencil, X, Upload, Trash2
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const defaultProfile = {
  name: "Diwakar",
  email: "diwakar@mindguard.ai",
  username: "Diwakar",
  emergency_contact: "+91 1234567890",
  avgMood: 3.4,
  riskLevel: "Moderate",
  avatar: null,
};

const avatar = localStorage.getItem("avatar") || "/avatar-default.png";


const moodBadge = (mood) => {
  if (mood >= 4) return "😄";
  if (mood >= 3) return "🙂";
  if (mood >= 2) return "😕";
  return "😞";
};

const riskColor = {
  Low: "bg-green-100 text-green-700",
  Moderate: "bg-yellow-100 text-yellow-800",
  High: "bg-red-100 text-red-700",
};

const Profile = () => {
  const [userData, setUserData] = useState(defaultProfile);
  const [editingField, setEditingField] = useState(null);
  const [inputValue, setInputValue] = useState("");

  useEffect(() => {
    const stored = localStorage.getItem("mindguard_profile");
    if (stored) setUserData(JSON.parse(stored));
  }, []);

  const openEdit = (field, current) => {
    setEditingField(field);
    setInputValue(current);
  };

  const saveEdit = () => {
    const updated = { ...userData, [editingField]: inputValue };
    setUserData(updated);
    localStorage.setItem("mindguard_profile", JSON.stringify(updated));
    setEditingField(null);
  };

  const handleAvatarUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result;
      const updated = { ...userData, avatar: base64 };
      setUserData(updated);
      localStorage.setItem("mindguard_profile", JSON.stringify(updated));
      localStorage.setItem("avatar", base64);
    };

    reader.readAsDataURL(file);
  };

  const resetProfile = () => {
    localStorage.removeItem("mindguard_profile");
    setUserData(defaultProfile);
  };

  return (
    <motion.div
      className="min-h-screen p-6 md:p-12 bg-gradient-to-br from-blue-50 to-indigo-100"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className="max-w-4xl mx-auto bg-white shadow-xl rounded-2xl p-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-indigo-700">👤 Profile Overview</h1>
          <button
            onClick={resetProfile}
            className="flex items-center gap-1 text-sm text-red-600 hover:underline"
          >
            <Trash2 className="w-4 h-4" /> Reset
          </button>
        </div>

        {/* Avatar */}
        <div className="flex flex-col items-center justify-center mt-4">
          <div className="w-24 h-24 rounded-full overflow-hidden shadow border-4 border-indigo-200 bg-white">
            <img
              src={userData.avatar || "/avatar-default.png"}
              alt="avatar"
              className="w-full h-full object-cover"
            />

          </div>
          <label className="mt-2 cursor-pointer text-blue-600 text-sm hover:underline flex items-center gap-1">
            <Upload className="w-4 h-4" /> Upload Photo
            <input type="file" accept="image/*" onChange={handleAvatarUpload} className="hidden" />
          </label>
        </div>

        {/* User Info */}
        <div className="space-y-3">
          {[
            ["name", <User className="text-indigo-500" />],
            ["email", <Mail className="text-indigo-500" />],
          ].map(([field, icon]) => (
            <div key={field} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {icon}
                <p className="font-medium capitalize">{field}:</p>
                <span>{userData[field]}</span>
              </div>
              <button onClick={() => openEdit(field, userData[field])}>
                <Pencil className="w-4 h-4 text-blue-500 hover:scale-110 transition" />
              </button>
            </div>
          ))}
          <div className="flex items-center gap-3">
            <span className="text-indigo-500">@</span>
            <p className="font-medium">Username:</p>
            <span>{userData.username}</span>
          </div>
        </div>

        {/* Emergency Contact */}
        <div className="pt-4 border-t flex items-center justify-between">
          <div className="flex items-center gap-3 text-gray-700">
            <Phone className="text-red-500" />
            <p>{userData.emergency_contact}</p>
          </div>
          <button
            onClick={() => openEdit("emergency_contact", userData.emergency_contact)}
          >
            <Pencil className="w-4 h-4 text-blue-500 hover:scale-110 transition" />
          </button>
        </div>

        {/* Account Settings */}
        <div className="pt-4 border-t">
          <h2 className="text-lg font-semibold text-gray-700 mb-2">
            🔐 Account Settings
          </h2>
          <div className="flex items-center gap-3">
            <Lock className="text-gray-500" />
            <p>Password: ********</p>
            <button className="ml-auto text-sm text-blue-600 hover:underline">
              Change
            </button>
          </div>
        </div>

        {/* Mental Health Metrics */}
        <div className="pt-4 border-t">
          <h2 className="text-lg font-semibold text-indigo-700 mb-2">
            📊 Mental Wellness Summary
          </h2>
          <div className="flex gap-6">
            <div className="bg-indigo-50 rounded-xl p-4 text-center shadow w-1/2">
              <p className="text-3xl font-bold text-indigo-600">
                {userData.avgMood}
              </p>
              <p className="text-sm text-gray-600">Avg Mood Score</p>
              <span className="text-2xl">{moodBadge(userData.avgMood)}</span>
            </div>
            <div
              className={`rounded-xl p-4 text-center shadow w-1/2 ${
                riskColor[userData.riskLevel] || "bg-gray-100 text-gray-700"
              }`}
            >
              <p className="text-lg font-bold">{userData.riskLevel}</p>
              <p className="text-sm">Risk Trend</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-6 border-t text-sm text-gray-500 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-green-600" />
          Your data is stored in our servers.
        </div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {editingField && (
          <motion.div
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-white p-6 rounded-xl shadow-lg w-full max-w-md"
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
            >
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-indigo-700 capitalize">
                  Edit {editingField.replace("_", " ")}
                </h2>
                <button onClick={() => setEditingField(null)}>
                  <X className="w-5 h-5 text-gray-500 hover:text-gray-800" />
                </button>
              </div>
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
              />
              <div className="flex justify-end gap-2 mt-4">
                <button
                  onClick={() => setEditingField(null)}
                  className="px-4 py-2 rounded bg-gray-200 text-gray-600 hover:bg-gray-300"
                >
                  Cancel
                </button>
                <button
                  onClick={saveEdit}
                  className="px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700"
                >
                  Save
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default Profile;
