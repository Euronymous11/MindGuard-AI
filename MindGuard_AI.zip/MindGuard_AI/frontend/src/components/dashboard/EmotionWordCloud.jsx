import React from "react";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";

const keywords = [
  { word: "calm", weight: 5 },
  { word: "happy", weight: 4 },
  { word: "focused", weight: 3 },
  { word: "anxious", weight: 2 },
  { word: "overwhelmed", weight: 2 },
  { word: "hopeful", weight: 3 },
  { word: "grateful", weight: 4 },
  { word: "sad", weight: 1 },
  { word: "energized", weight: 3 },
  { word: "stressed", weight: 2 },
];

const fontSizeMap = {
  1: "text-xs",
  2: "text-sm",
  3: "text-base",
  4: "text-lg",
  5: "text-xl",
};

const EmotionKeywordCloud = () => {
  return (
    <motion.div
      className="bg-white rounded-xl p-4 shadow-md"
      initial={{ opacity: 0, y: 25 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <h3 className="text-lg font-bold text-blue-700 mb-3 flex items-center gap-2">
        <Sparkles size={18} className="text-indigo-500" />
        🔠 Emotion Word Bubble
      </h3>

      <div className="flex flex-wrap gap-3">
        {keywords.map((item, i) => (
          <motion.span
            key={i}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: i * 0.05 }}
            className={`px-3 py-1 rounded-full bg-blue-100 text-blue-800 font-semibold ${fontSizeMap[item.weight]}`}
          >
            {item.word}
          </motion.span>
        ))}
      </div>
    </motion.div>
  );
};

export default EmotionKeywordCloud;
