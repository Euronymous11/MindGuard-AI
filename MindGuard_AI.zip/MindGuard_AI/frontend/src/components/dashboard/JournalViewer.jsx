import React, { useEffect } from "react";
import { motion } from "framer-motion";
import confetti from "canvas-confetti";

const JournalViewer = ({ journals }) => {
  // Dummy fallback data for test user mode
  const dummyJournals = [
    {
      entry: "Woke up feeling energetic and focused. Completed my top 3 tasks.",
      timestamp: "2025-05-12T09:15:00", // ✅ Today
    },
    {
      entry: "Felt anxious but managed through breathwork.",
      timestamp: "2025-05-11T18:00:00",
    },
  ];

  const safeJournals = dummyJournals;

  useEffect(() => {
    if (safeJournals.length >= 3) {
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    }
  }, []);

  const highlight = (text) => {
    return text.replace(
      /(anxious|calm|productive|overwhelmed|happy|stressed|relaxed|focused)/gi,
      (match) => `<strong class="text-blue-700">${match}</strong>`
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 25 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="p-4 rounded-lg bg-white shadow-md"
    >
      <h3 className="text-lg font-semibold mb-4">📝 Micro-Journals</h3>

      <div className="space-y-4">
        {safeJournals.length === 0 ? (
          <p className="text-sm text-gray-500 italic">No journals recorded yet.</p>
        ) : (
          safeJournals.map((journal, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="border p-4 rounded-lg shadow-sm bg-gray-50 hover:bg-gray-100 transition"
              title={new Date(journal.timestamp).toLocaleString()}
            >
              <p
                className="text-base text-gray-800"
                dangerouslySetInnerHTML={{ __html: highlight(journal.entry) }}
              />
              <div className="text-xs text-gray-500 mt-2 flex justify-between">
                <span>{new Date(journal.timestamp).toLocaleDateString()}</span>
                <span>{journal.entry.split(" ").length} words</span>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </motion.div>
  );
};

export default JournalViewer;
