import React from "react";
import { motion } from "framer-motion";
import { BrainCircuit } from "lucide-react";

const bloomLevels = [
  { label: "Remember", value: 3, color: "bg-gray-400" },
  { label: "Understand", value: 4, color: "bg-blue-400" },
  { label: "Apply", value: 2, color: "bg-green-400" },
  { label: "Analyze", value: 1, color: "bg-yellow-400" },
  { label: "Evaluate", value: 0, color: "bg-orange-400" },
  { label: "Create", value: 1, color: "bg-purple-400" },
];

const icapLevels = [
  { label: "Passive", value: 2, color: "bg-gray-300" },
  { label: "Active", value: 3, color: "bg-blue-300" },
  { label: "Constructive", value: 1, color: "bg-green-300" },
  { label: "Interactive", value: 0, color: "bg-indigo-300" },
];

const RibbonBar = ({ label, value, color }) => (
  <div className="flex flex-col items-start w-full">
    <p className="text-xs text-gray-600 mb-1">{label}</p>
    <motion.div
      initial={{ width: 0 }}
      animate={{ width: `${value * 20}%` }}
      transition={{ duration: 0.6 }}
      className={`h-4 ${color} rounded`}
    />
  </div>
);

const CognitiveInsightRibbon = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 25 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white rounded-xl shadow-md p-4"
    >
      <h3 className="text-lg font-bold text-blue-700 mb-2 flex items-center gap-2">
        <BrainCircuit className="text-blue-600" size={20} />
        🧠 Cognitive Insight (Bloom & ICAP)
      </h3>

      <div className="mb-4">
        <p className="text-sm font-medium text-gray-700 mb-1">Bloom's Taxonomy</p>
        <div className="space-y-2">
          {bloomLevels.map((level, i) => (
            <RibbonBar key={i} {...level} />
          ))}
        </div>
      </div>

      <div>
        <p className="text-sm font-medium text-gray-700 mb-1">ICAP Engagement</p>
        <div className="space-y-2">
          {icapLevels.map((level, i) => (
            <RibbonBar key={i} {...level} />
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default CognitiveInsightRibbon;
