// src/components/chat/ChatBox.jsx

import React, { useRef, useState } from "react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import confetti from "canvas-confetti";

const emotionIcons = {
  happy: "😊", sad: "😢", angry: "😠", calm: "😌",
  fearful: "😨", surprised: "😲", disgusted: "🤢", neutral: "😐",
};

const emotionGradients = {
  happy: "bg-yellow-50",
  sad: "bg-blue-50",
  angry: "bg-red-50",
  calm: "bg-green-50",
  fearful: "bg-purple-50",
  surprised: "bg-pink-50",
  disgusted: "bg-lime-50",
  neutral: "bg-gray-100",
};

const reactions = ["👍", "❤️", "😂", "😢"];

const ChatBox = ({
  message = "",
  isUser = false,
  timestamp = null,
  emotion = null,
  voice_url = null,
  isTyping = false,
}) => {
  const [selectedReaction, setSelectedReaction] = useState(null);
  const bubbleRef = useRef(null);

  const handleReaction = (reaction) => {
    setSelectedReaction(reaction === selectedReaction ? null : reaction);
    confetti({
      particleCount: 40,
      spread: 60,
      origin: { y: 0.6 },
    });
  };

  const formattedTime = () => {
    try {
      if (!timestamp) return "";
      const dateObj = typeof timestamp === "string" ? new Date(timestamp) : timestamp;
      if (isNaN(dateObj)) return "";
      return format(dateObj, "HH:mm");
    } catch {
      return "";
    }
  };

  const bubbleClass = isUser
    ? "bg-blue-100 text-right"
    : `${emotionGradients[emotion?.emotion] || "bg-white"} text-left`;

  return (
    <motion.div
      className={`flex px-4 py-2 ${isUser ? "justify-end" : "justify-start"}`}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div
        ref={bubbleRef}
        className={`relative max-w-[85%] sm:max-w-[70%] md:max-w-[60%] p-4 rounded-2xl shadow text-sm whitespace-pre-wrap break-words transition-all ${bubbleClass}`}
      >
        {/* Emotion Icon */}
        {!isUser && emotion?.emotion && (
          <div className="absolute -top-3 -left-3 bg-white border rounded-full px-2 py-1 text-xs shadow-sm">
            {emotionIcons[emotion?.emotion] || "💬"}
          </div>
        )}

        {/* Typing or Message */}
        {isTyping ? (
          <div className="flex gap-1 pl-1 mt-1">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="bg-gray-400 w-2 h-2 rounded-full"
                animate={{ y: [0, -5, 0] }}
                transition={{
                  duration: 0.6,
                  delay: i * 0.2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
            ))}
          </div>
        ) : (
          <p>{message}</p>
        )}

        {/* Voice Message */}
        {voice_url && (
          <audio controls className="mt-2 w-full rounded-md border">
            <source src={voice_url} type="audio/mpeg" />
            Your browser does not support the audio element.
          </audio>
        )}

        {/* Timestamp & Reactions */}
        <div className="mt-2 flex items-center justify-between text-xs text-gray-500">
          <span>{formattedTime()}</span>
          {!isUser && (
            <div className="flex items-center gap-1 ml-2">
              {reactions.map((r) => (
                <button
                  key={r}
                  className={`transition-transform hover:scale-125 ${selectedReaction === r ? "scale-150" : ""}`}
                  onClick={() => handleReaction(r)}
                >
                  {r}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Floating Reaction */}
        {selectedReaction && (
          <motion.div
            className="absolute -top-3 -right-3 text-xl"
            animate={{ scale: [1, 1.5, 1] }}
            transition={{ duration: 0.4 }}
          >
            {selectedReaction}
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

export default ChatBox;
