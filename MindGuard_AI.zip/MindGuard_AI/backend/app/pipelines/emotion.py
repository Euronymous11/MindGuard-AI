"""Pipeline Module: emotion.py"""

# app/pipelines/emotion.py

import os
from typing import Dict

import requests

# === Optional Hugging Face Model Config ===
HUGGINGFACE_API_URL = "https://api-inference.huggingface.co/models/j-hartmann/emotion-english-distilroberta-base"
HUGGINGFACE_API_KEY = os.getenv("HUGGINGFACE_API_KEY")  # Set this in your .env

HEADERS = (
    {"Authorization": f"Bearer {HUGGINGFACE_API_KEY}"} if HUGGINGFACE_API_KEY else {}
)

# === Fallback Keyword Mapping ===
KEYWORD_EMOTIONS = {
    "sad": "sadness",
    "depressed": "sadness",
    "cry": "sadness",
    "worthless": "sadness",
    "angry": "anger",
    "mad": "anger",
    "furious": "anger",
    "hate": "anger",
    "scared": "fear",
    "afraid": "fear",
    "panic": "fear",
    "anxious": "fear",
    "happy": "joy",
    "grateful": "joy",
    "love": "joy",
    "excited": "joy",
    "meh": "neutral",
    "okay": "neutral",
    "fine": "neutral",
}


def analyze_emotion(text: str) -> Dict[str, str]:
    """
    Analyze emotion using HuggingFace API (or fallback if unavailable).
    Returns dict with emotion label and confidence if available.
    """
    if HUGGINGFACE_API_KEY:
        try:
            response = requests.post(
                HUGGINGFACE_API_URL, headers=HEADERS, json={"inputs": text}, timeout=8
            )
            response.raise_for_status()
            results = response.json()
            if isinstance(results, list) and len(results) > 0:
                top_result = max(results[0], key=lambda x: x["score"])
                return {
                    "emotion": top_result["label"].lower(),
                    "confidence": f"{top_result['score']:.2f}",
                }
        except Exception as e:
            print(f"[EmotionAnalyzer] API fallback due to error: {e}")

    # === Fallback: Keyword Matching ===
    text_lower = text.lower()
    for keyword, emotion in KEYWORD_EMOTIONS.items():
        if keyword in text_lower:
            return {"emotion": emotion, "confidence": "fallback"}
    return {"emotion": "neutral", "confidence": "fallback"}
