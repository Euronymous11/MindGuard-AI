import React, { useEffect, useState } from "react";
import axios from "axios";
import { motion } from "framer-motion";

const moodColors = {
  1: "bg-red-200 border-red-400",
  2: "bg-orange-200 border-orange-400",
  3: "bg-yellow-200 border-yellow-400",
  4: "bg-green-200 border-green-400",
  5: "bg-emerald-300 border-emerald-500",
};

const moodLabels = {
  1: "Very Low",
  2: "Low",
  3: "Neutral",
  4: "Good",
  5: "Excellent",
};

const moodEmojis = {
  1: "😢",
  2: "😟",
  3: "😐",
  4: "😊",
  5: "😄",
};

const MoodCalendar = () => {
  const [moods, setMoods] = useState([]);

 const dummyMoods = [
  { mood_date: "2025-05-01", mood_score: 3 },
  { mood_date: "2025-05-02", mood_score: 4 },
  { mood_date: "2025-05-03", mood_score: 2 },
  { mood_date: "2025-05-04", mood_score: 5 },
  { mood_date: "2025-05-05", mood_score: 4 },
  { mood_date: "2025-05-06", mood_score: 3 },
  { mood_date: "2025-05-07", mood_score: 3 },
  { mood_date: "2025-05-08", mood_score: 4 },
  { mood_date: "2025-05-09", mood_score: 5 },
  { mood_date: "2025-05-10", mood_score: 4 },
  { mood_date: "2025-05-11", mood_score: 4 },
  { mood_date: "2025-05-12", mood_score: 5 }, // ✅ Today
];


  useEffect(() => {
    setMoods(dummyMoods);
  }, []);

  const today = new Date();
  const currentMonth = today.getMonth();
  const currentDate = today.getDate();
  const daysInMonth = new Date(today.getFullYear(), currentMonth + 1, 0).getDate();

  const moodMap = (Array.isArray(moods) ? moods : []).reduce((acc, m) => {
    if (!m || !m.mood_date) return acc;
    const d = new Date(m.mood_date).getDate();
    acc[d] = m.mood_score;
    return acc;
  }, {});

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="p-4 rounded-lg bg-white shadow-md"
    >
      <h3 className="text-lg font-semibold mb-4">📆 Monthly Mood Calendar</h3>

      <div className="grid grid-cols-7 gap-2 text-center text-sm">
        {[...Array(daysInMonth)].map((_, i) => {
          const day = i + 1;
          const mood = moodMap[day];
          const emoji = moodEmojis[mood];
          const label = moodLabels[mood];

          const isToday = day === currentDate;
          const baseStyle = moodColors[mood] || "bg-gray-100 border-gray-300";

          return (
            <div
              key={day}
              className={`p-2 rounded border transition duration-200 ${baseStyle} ${
                isToday ? "animate-pulse font-bold ring-2 ring-blue-400" : ""
              }`}
            >
              <div>{day}</div>
              {mood && <div className="text-xs">{emoji} {label}</div>}
            </div>
          );
        })}
      </div>
    </motion.div>
  );
};

export default MoodCalendar;
