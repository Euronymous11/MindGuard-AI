"""Pipeline Module: sentiment.py"""

from transformers import pipeline

# Load once on module import
_sentiment_pipeline = pipeline(
    "sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english"
)


def analyze_sentiment(text: str) -> dict:
    try:
        result = _sentiment_pipeline(text[:512])[0]  # truncate for safety
        label = result["label"]
        score = round(result["score"], 3)
        return {"label": label, "score": score}
    except Exception as e:
        print("Sentiment analysis failed:", e)
        return {"label": "NEUTRAL", "score": 0.0}
